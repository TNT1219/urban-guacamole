# Go Commentary Engine
A professional-level Go/Baduk game analysis and commentary system built with Python.

## Overview
This project implements a sophisticated Go analysis engine capable of interpreting move intentions and providing commentary at a professional player level. The system leverages the powerful Katago engine for accurate position evaluation while adding custom analysis and professional-level commentary generation.

## Features
- SGF file parsing for game records
- Comprehensive position analysis powered by Katago
- Move intention interpretation
- Professional-level commentary generation
- Tactical and strategic assessment
- Pattern recognition
- Flexible architecture supporting both Katago-powered and basic analysis modes

## Installation

### Prerequisites
- Python 3.7+
- Katago engine (optional but recommended for professional-level analysis)

### Basic Installation
```bash
pip install -r requirements.txt
```

### Katago Integration
For professional-level analysis, install Katago:
1. Download from: https://github.com/lightvector/KataGo/releases
2. Download a neural network model from the same page
3. Update the paths in your configuration

See [INSTALLATION.md](INSTALLATION.md) for detailed instructions.

## Usage
```python
from go_commentary_engine import GoCommentarySystem

# Create a system instance with Katago integration
system = GoCommentarySystem(use_katago=True, katago_path="/path/to/katago")

# Or create a basic system without Katago
system = GoCommentarySystem(use_katago=False)

# Analyze a game from SGF file
commentary = system.analyze_game("path/to/game.sgf")

# Or analyze a single position
result = system.analyze_single_position(board_state, current_player)
```

## Architecture
The system consists of several key components:
- **Board**: Core Go board representation and rules
- **SGF Parser**: Handles game record parsing
- **Katago Interface**: Communicates with the Katago engine for advanced analysis
- **Analysis Engine**: Performs position and move analysis, with fallback to built-in analysis
- **Commentary Generator**: Creates natural language commentary
- **Pattern Recognizer**: Identifies common Go patterns

## Development Status
The system now integrates with Katago for professional-level analysis. The architecture allows for both advanced Katago-powered analysis and basic built-in analysis, providing flexibility based on available resources.