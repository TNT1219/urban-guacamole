#!/usr/bin/env python3
"""
Demo script showcasing the professional commentary generation
This demonstrates the second phase - the core of the professional-level commentary system
"""

from go_commentary_engine import MoveIntentInterpreter, KatagoAnalysisProcessor
import json


def demo_commentary_generation():
    """Demonstrate the professional commentary generation capabilities"""
    print("Go Commentary Engine - Professional Commentary Generation Demo")
    print("="*70)
    print("This demo focuses on Phase 2: Professional Commentary Generation")
    print("="*70)
    
    # Initialize the intent interpreter
    interpreter = MoveIntentInterpreter()
    processor = KatagoAnalysisProcessor()
    
    print("✓ Initialized Move Intent Interpreter")
    print("✓ Professional terminology and commentary templates loaded")
    
    # Simulate some sample Katago analysis data
    # In a real scenario, this would come from Katago's analysis
    sample_katago_data = {
        'moves': [
            {
                'move': 'Q4',
                'visits': 8542,
                'winrate': 52.3,
                'prior': 0.15,
                'lcb': 51.8,
                'order': 1,
                'pv': ['Q4', 'D16', 'Q16', 'D4', 'C6']
            },
            {
                'move': 'D16',
                'visits': 7201,
                'winrate': 48.7,
                'prior': 0.12,
                'lcb': 47.9,
                'order': 2,
                'pv': ['D16', 'Q4', 'D4', 'Q16', 'C6']
            }
        ],
        'position_eval': {
            'centipawn': 23,
            'winrate': 52.3
        },
        'winrate_graph': [],
        'pv_sequence': ['Q4', 'D16', 'Q16']
    }
    
    print("\nSimulating Katago analysis input...")
    print(f"  - Top move: {sample_katago_data['moves'][0]['move']} with {sample_katago_data['moves'][0]['visits']} visits")
    print(f"  - Black winrate: {sample_katago_data['moves'][0]['winrate']}%")
    print(f"  - Position value: +{sample_katago_data['position_eval']['centipawn']/100:.2f} points for Black")
    
    # Interpret the analysis
    print("\nProcessing analysis through Move Intent Interpreter...")
    interpretation = interpreter.interpret_katago_analysis(sample_katago_data)
    
    print("✓ Analysis interpreted")
    print(f"  - Move quality: {interpretation['move_quality']}")
    print(f"  - Strategic insights: {len(interpretation['strategic_insights'])} points")
    print(f"  - Tactical notes: {len(interpretation['tactical_notes'])} points")
    print(f"  - Suggestions: {len(interpretation['suggestions'])} alternatives")
    
    # Generate professional commentary
    print("\nGenerating professional commentary...")
    commentary = interpretation['commentary']
    
    print("\n" + "="*70)
    print("PROFESSIONAL COMMENTARY OUTPUT")
    print("="*70)
    print(commentary)
    print("="*70)
    
    # Show how move-specific commentary would work
    print("\nDemonstrating move-specific commentary:")
    move_commentary = interpreter.generate_move_commentary(
        move_coords=(16, 3),  # Q4 in 0-indexed coordinates
        katago_analysis=sample_katago_data,
        board_state_description="Opening position with enclosures at Q16 and D4"
    )
    print(f"Move Q4 commentary: {move_commentary}")
    
    print("\n" + "="*70)
    print("KEY CAPABILITIES OF PHASE 2 SYSTEM:")
    print("="*70)
    print("• Translates raw Katago data into professional Go terminology")
    print("• Provides strategic and tactical explanations")
    print("• Generates human-understandable commentary")
    print("• Identifies missed opportunities and alternatives")
    print("• Uses professional-level Go vocabulary")
    print("• Context-aware commentary based on game phase")
    print("• Move quality assessment")
    print("• Suggestion of better alternatives when applicable")
    print("="*70)
    
    print("\nThe second phase - professional commentary generation - forms the")
    print("core value proposition of the system. While Katago provides the")
    print("computational power for accurate analysis, this module transforms")
    print("that analysis into insightful, educational commentary that mimics")
    print("professional Go commentary.")


if __name__ == "__main__":
    demo_commentary_generation()