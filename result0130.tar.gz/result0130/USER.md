# USER.md - About Your Human

*Learn about the person you're helping. Update this as you go.*

- **Name:** Tom
- **What to call them:** Tom
- **Pronouns:** *(optional)*
- **Timezone:** Asia/Shanghai (北京时间)
- **Notes:** 用户通过Feishu联系，叫我小龙虾

## Context

*(What do they care about? What projects are they working on? What annoys them? What makes them laugh? Build this over time.)*

---