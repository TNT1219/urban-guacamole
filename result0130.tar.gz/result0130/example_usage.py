#!/usr/bin/env python3
"""
Example script demonstrating the Go Commentary Engine with Katago integration
"""

from go_commentary_engine import GoCommentarySystem, GoBoard
import os


def demo_with_katago():
    """Demonstrate the system with Katago integration"""
    print("Go Commentary Engine - Katago Integration Demo")
    print("="*60)
    
    # Check if Katago is available
    katago_available = os.system("which katago > /dev/null 2>&1") == 0
    
    if katago_available:
        print("✓ Katago detected on system")
        # Initialize with Katago
        system = GoCommentarySystem(use_katago=True)
        print("✓ System initialized with Katago support")
    else:
        print("⚠ Katago not found, using basic analysis engine")
        # Initialize without Katago
        system = GoCommentarySystem(use_katago=False)
        print("✓ System initialized with basic analysis")
    
    # Create a sample board position
    board = GoBoard()
    
    # Simulate a few moves to create an interesting position
    try:
        board.play_move(3, 3)  # Black
        board.play_move(15, 15)  # White
        board.play_move(3, 15)  # Black
        board.play_move(15, 3)  # White
        print("✓ Created sample position with 4 moves")
    except Exception as e:
        print(f"Note: {e}")
    
    # Analyze the position
    print("\nAnalyzing position...")
    analysis = system.analysis_engine.analyze_position(board)
    
    print(f"✓ Position analysis completed")
    print(f"  - Black advantage: {analysis['position_evaluation']['black_advantage']:.2f}")
    print(f"  - Win probability: {analysis['position_evaluation']['win_probability']:.2%}")
    print(f"  - Complexity: {analysis['position_evaluation']['complexity']:.2f}")
    
    # Generate commentary
    print("\nGenerating commentary...")
    commentary = system.commentary_generator.generate_commentary(analysis)
    print(f"✓ Commentary generated successfully")
    
    print("\n" + "="*60)
    print("SAMPLE COMMENTARY:")
    print("="*60)
    print(commentary)
    print("="*60)
    
    # Demonstrate move analysis if possible
    if katago_available:
        print("\nKatago integration allows for:")
        print("- Professional-level position evaluation")
        print("- Accurate win rate calculations") 
        print("- Detailed move analysis with visit counts")
        print("- Principal variation analysis")
    else:
        print("\nBasic analysis includes:")
        print("- Fundamental position evaluation")
        print("- Tactical situation detection")
        print("- Strategic element analysis")
        print("- Pattern recognition")
    
    print("\nThis system can be extended to:")
    print("- Process complete SGF files")
    print("- Provide move-by-move commentary")
    print("- Highlight critical mistakes")
    print("- Suggest better alternatives")
    print("- Analyze professional games")


if __name__ == "__main__":
    demo_with_katago()