# Installation Guide for Go Commentary Engine with Katago

## Installing Katago

### Option 1: Pre-built Binary (Recommended)
Download the latest release from:
https://github.com/lightvector/KataGo/releases

Extract and make it executable:
```bash
tar -xzf katago-*-linux-x64.tar.gz  # or the appropriate archive for your system
chmod +x katago
# Move to a location in your PATH or note the path
```

### Option 2: Using Package Manager
Some distributions have Katago in their repositories:
```bash
# Ubuntu/Debian
sudo apt install katago

# Arch Linux
yay -S katago  # or paru -S katago
```

### Option 3: Build from Source
```bash
git clone https://github.com/lightvector/KataGo.git
cd KataGo
make -j
```

## Required Models

Katago requires neural network models to function. Download a model from:
https://github.com/lightvector/KataGo/releases/tag/v1.13.0

Look for a file like `g170-b30c320x2-s1450404992-d26ee9495b9a.info.txt` or similar.

## Configuration

1. Update the katago_path in your code to point to your Katago binary
2. Update the model_path to point to your downloaded model file

## Testing

After installation, you can test the integration:

```python
from go_commentary_engine import GoCommentarySystem

# Initialize with Katago
system = GoCommentarySystem(use_katago=True, katago_path="/path/to/katago")

# The system will fall back to basic analysis if Katago is not available
```

## Alternative: Basic Mode

If you don't want to use Katago, you can run in basic mode:

```python
# This will use the built-in analysis engine without Katago
system = GoCommentarySystem(use_katago=False)
```

Note: Basic mode has limited analysis capability compared to Katago-powered analysis.