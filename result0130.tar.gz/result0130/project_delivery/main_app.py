#!/usr/bin/env python3
"""
Go Commentary Engine - Main Application
This is a simple entry point for the Go Commentary Engine
"""

from go_commentary_engine import GoCommentarySystem
from go_commentary_engine.board import GoBoard
import sys


def main():
    print("Go Commentary Engine - Professional Go Analysis System")
    print("=" * 60)
    
    if len(sys.argv) < 2:
        print("Usage:")
        print("  python main_app.py <sgf_file>           # Analyze SGF file")
        print("  python main_app.py --demo               # Run demo analysis")
        print("  python main_app.py --basic-demo         # Run basic demo without Katago")
        return
    
    command = sys.argv[1]
    
    if command == "--demo" or command == "--basic-demo":
        use_katago = command != "--basic-demo"
        print(f"Initializing system (Katago: {use_katago})...")
        
        try:
            system = GoCommentarySystem(use_katago=use_katago)
            print("✓ System initialized successfully")
            
            # Create a sample position
            board = GoBoard()
            print("✓ Sample board created")
            
            # Analyze the position
            analysis = system.analysis_engine.analyze_position(board)
            print("✓ Position analyzed")
            
            # Generate commentary
            commentary = system.commentary_generator.generate_commentary(analysis)
            print("\n" + "="*60)
            print("SAMPLE COMMENTARY")
            print("="*60)
            print(commentary)
            print("="*60)
            
        except Exception as e:
            print(f"Error: {e}")
            print("Make sure all dependencies are installed")
            
    elif command.endswith('.sgf'):
        sgf_file = command
        print(f"Analyzing SGF file: {sgf_file}")
        
        try:
            system = GoCommentarySystem(use_katago=True)
            commentary = system.analyze_game(sgf_file)
            
            print(f"Analysis complete! Found {len(commentary)} moves.")
            for i, item in enumerate(commentary[:5]):  # Show first 5 moves
                print(f"Move {item['move_number']}: {item['commentary'][:100]}...")
                
            if len(commentary) > 5:
                print(f"... and {len(commentary) - 5} more moves")
                
        except Exception as e:
            print(f"Error analyzing file: {e}")
    else:
        print(f"Unknown command: {command}")
        print("Use --demo or --basic-demo for examples")


if __name__ == "__main__":
    main()