"""
Go Board representation and management
Handles the core logic of the Go game
"""
import numpy as np
from enum import Enum


class Stone(Enum):
    EMPTY = 0
    BLACK = 1
    WHITE = 2


class GoBoard:
    def __init__(self, size=19):
        self.size = size
        self.board = np.zeros((size, size), dtype=int)
        self.current_player = Stone.BLACK
        self.ko_point = None
        self.captured_black = 0
        self.captured_white = 0
        self.move_history = []
    
    def copy(self):
        """Return a copy of the current board"""
        new_board = GoBoard(self.size)
        new_board.board = self.board.copy()
        new_board.current_player = self.current_player
        new_board.ko_point = self.ko_point
        new_board.captured_black = self.captured_black
        new_board.captured_white = self.captured_white
        new_board.move_history = self.move_history.copy()
        return new_board
    
    def is_valid_move(self, x, y):
        """Check if a move is valid"""
        if x < 0 or x >= self.size or y < 0 or y >= self.size:
            return False
        
        if self.board[x][y] != Stone.EMPTY.value:
            return False
        
        if (x, y) == self.ko_point:
            return False
        
        # Temporarily place the stone to check for suicide
        temp_board = self.board.copy()
        temp_board[x][y] = self.current_player.value
        
        # Check if the placed stone has liberties
        if not self._has_liberties(temp_board, x, y, self.current_player.value):
            # Check if the move captures opponent stones (which would make it valid)
            opponent = Stone.WHITE if self.current_player == Stone.BLACK else Stone.BLACK
            captured_stones = self._get_captured_stones(temp_board, x, y, opponent.value)
            
            if len(captured_stones) == 0:
                return False  # Suicide move
        
        return True
    
    def _has_liberties(self, board, x, y, color):
        """Check if a stone/group at (x,y) has liberties"""
        visited = set()
        stack = [(x, y)]
        
        while stack:
            cx, cy = stack.pop()
            if (cx, cy) in visited:
                continue
            
            visited.add((cx, cy))
            
            # Check adjacent points
            for dx, dy in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                nx, ny = cx + dx, cy + dy
                
                if 0 <= nx < self.size and 0 <= ny < self.size:
                    if board[nx][ny] == 0:  # Empty point (liberty)
                        return True
                    elif board[nx][ny] == color and (nx, ny) not in visited:
                        stack.append((nx, ny))
        
        return False
    
    def _get_captured_stones(self, board, x, y, opponent_color):
        """Get stones that would be captured by placing at (x,y)"""
        captured = []
        
        for dx, dy in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
            nx, ny = x + dx, y + dy
            
            if 0 <= nx < self.size and 0 <= ny < self.size and board[nx][ny] == opponent_color:
                group = self._get_group(board, nx, ny)
                
                if not self._has_liberties_after_move(board, group, x, y):
                    captured.extend(group)
        
        return captured
    
    def _get_group(self, board, x, y):
        """Get the entire group of connected stones"""
        color = board[x][y]
        if color == 0:
            return []
        
        visited = set()
        stack = [(x, y)]
        group = []
        
        while stack:
            cx, cy = stack.pop()
            if (cx, cy) in visited:
                continue
            
            visited.add((cx, cy))
            group.append((cx, cy))
            
            for dx, dy in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                nx, ny = cx + dx, cy + dy
                
                if (0 <= nx < self.size and 0 <= ny < self.size and 
                    board[nx][ny] == color and (nx, ny) not in visited):
                    stack.append((nx, ny))
        
        return group
    
    def _has_liberties_after_move(self, board, group, x, y):
        """Check if a group has liberties after a move is played"""
        # Temporarily place the stone
        original_value = board[x][y]
        board[x][y] = 3 - original_value  # Switch player
        
        # Check liberties for the group
        has_libs = False
        for gx, gy in group:
            if self._has_liberties(board, gx, gy, board[gx][gy]):
                has_libs = True
                break
        
        # Restore original value
        board[x][y] = original_value
        
        return has_libs
    
    def play_move(self, x, y):
        """Play a move on the board"""
        if not self.is_valid_move(x, y):
            raise ValueError(f"Invalid move: ({x}, {y})")
        
        # Place the stone
        self.board[x][y] = self.current_player.value
        self.move_history.append((x, y, self.current_player))
        
        # Capture opponent stones
        opponent = Stone.WHITE if self.current_player == Stone.BLACK else Stone.BLACK
        captured_stones = self._get_captured_stones(self.board, x, y, opponent.value)
        
        for cx, cy in captured_stones:
            self.board[cx][cy] = Stone.EMPTY.value
        
        if opponent == Stone.BLACK:
            self.captured_black += len(captured_stones)
        else:
            self.captured_white += len(captured_stones)
        
        # Handle ko rule
        if len(captured_stones) == 1:
            # Could potentially be a ko situation
            # Check if our placed stone is in atari (has only one liberty)
            if not self._check_if_ko(x, y):
                self.ko_point = None
            else:
                # This is a simplified ko implementation
                # In a real implementation, we'd need more sophisticated tracking
                pass
        
        # Switch player
        self.current_player = Stone.WHITE if self.current_player == Stone.BLACK else Stone.BLACK
    
    def _check_if_ko(self, x, y):
        """Check if a move creates a ko situation"""
        # Simplified ko detection
        # A full implementation would require checking the previous board state
        return False
    
    def get_legal_moves(self):
        """Get all legal moves for the current position"""
        moves = []
        for x in range(self.size):
            for y in range(self.size):
                if self.is_valid_move(x, y):
                    moves.append((x, y))
        return moves
    
    def calculate_territory(self):
        """Calculate territory for both players"""
        # Simple territory calculation
        # In practice, this would need to handle complex endgame situations
        black_territory = 0
        white_territory = 0
        neutral_points = 0
        
        # For now, return a simple count
        for x in range(self.size):
            for y in range(self.size):
                if self.board[x][y] == Stone.BLACK.value:
                    black_territory += 1
                elif self.board[x][y] == Stone.WHITE.value:
                    white_territory += 1
                else:
                    # This is a simplification - determining true territory requires flood fill
                    pass
        
        return {
            'black_territory': black_territory,
            'white_territory': white_territory,
            'captured_black': self.captured_black,
            'captured_white': self.captured_white
        }