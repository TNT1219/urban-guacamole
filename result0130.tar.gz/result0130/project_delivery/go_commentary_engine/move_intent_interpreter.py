"""
Move Intent Interpreter - Interprets Katago analysis and generates professional commentary
This is the core of the professional-level commentary system
"""
from typing import Dict, List, Any, Tuple
from .katago_interface import KatagoAnalysisProcessor
import re


class MoveIntentInterpreter:
    """
    Interprets Katago analysis data and translates it into professional-level commentary
    This is the key component that differentiates our system
    """
    
    def __init__(self):
        self.processor = KatagoAnalysisProcessor()
        self.go_terms = self._load_go_terms()
        self.commentary_templates = self._load_commentary_templates()
        
    def _load_go_terms(self) -> Dict[str, List[str]]:
        """
        Load professional Go terminology organized by concept
        """
        return {
            'fuseki': [
                'opening', 'enclosure', 'approach', 'invade', 'extend', 
                'shoulder hit', 'high approach', 'low approach', 'framework'
            ],
            'middle_game': [
                'fighting', 'attacking', 'defending', 'cutting', 'connecting',
                'life and death', 'semeai', 'aji', 'thickness', 'lightness',
                'sacrifice', 'compensation', 'escalation'
            ],
            'endgame': [
                'yose', 'gote', 'sente', 'reverse sente', 'miai', 'tsuke',
                'boundary', 'mutual damage', 'ko fight', 'temple escape'
            ],
            'shape': [
                'good shape', 'bad shape', 'empty triangle', 'bamboo joint',
                'one point jump', 'two point jump', 'diagonal', 'dogzuki',
                'bulky five', 'crosscut', 'hane', 'ikken tobi'
            ],
            'evaluation': [
                'Black is ahead', 'White is ahead', 'Even position', 
                'Complicated position', 'Sharp position', 'Quiet position',
                'Advantage', 'Mistake', 'Blunder', 'Inaccuracy'
            ]
        }
    
    def _load_commentary_templates(self) -> Dict[str, List[str]]:
        """
        Load templates for different types of commentary
        """
        return {
            'positive_move': [
                "An excellent move that {purpose}. This demonstrates deep understanding of the position.",
                "A strong choice that {purpose}, showing good positional judgment.",
                "The correct approach in this position, which {purpose}.",
                "A well-calculated move that {purpose}, maintaining the initiative."
            ],
            'negative_move': [
                "This move appears to {problem}, allowing the opponent to gain the upper hand.",
                "A questionable decision that {problem}, giving away the advantage.",
                "This move fails to {purpose}, which is critical in this position.",
                "The position called for a different approach, as this move {problem}."
            ],
            'missed_opportunity': [
                "The stronger move would have been {alternative}, which {benefit}.",
                "Black/White missed the chance to play {alternative}, which would have {benefit}.",
                "The computer suggests {alternative}, which {benefit} in this position.",
                "A more effective approach would be {alternative}, gaining {benefit}."
            ],
            'strategic_assessment': [
                "The position is strategically complex with both sides having {characteristic}.",
                "This is a typical {type} position where {principle} is important.",
                "The position favors whoever can {strategic_element}.",
                "Both players have achieved their objectives, leading to a {assessment} game."
            ],
            'tactical_explanation': [
                "The reason this move works is that it {tactical_reason}.",
                "This move threatens to {tactical_threat}, forcing the opponent to respond.",
                "The tactical point is that if Black/White plays elsewhere, then {sequence}.",
                "The move contains a hidden threat: if ignored, {consequence}."
            ],
            'pattern_explanation': [
                "This is the classical approach to this type of position.",
                "A modern innovation departing from traditional theory.",
                "Following the standard joseki, which results in {outcome}.",
                "Deviation from standard patterns, attempting to {goal}."
            ]
        }
    
    def interpret_katago_analysis(self, katago_analysis: Dict[str, Any], 
                                 previous_analysis: Dict[str, Any] = None) -> Dict[str, Any]:
        """
        Interpret Katago's analysis and extract professional-level insights
        """
        if not katago_analysis:
            return {
                'commentary': "No Katago analysis available for this position.",
                'move_quality': 'unknown',
                'strategic_insights': [],
                'tactical_notes': [],
                'suggestions': []
            }
        
        insights = {
            'move_quality': self._assess_move_quality(katago_analysis, previous_analysis),
            'strategic_insights': self._extract_strategic_insights(katago_analysis),
            'tactical_notes': self._extract_tactical_notes(katago_analysis),
            'suggestions': self._generate_suggestions(katago_analysis),
            'commentary': self._generate_professional_commentary(katago_analysis, previous_analysis)
        }
        
        return insights
    
    def _assess_move_quality(self, current_analysis: Dict[str, Any], 
                           previous_analysis: Dict[str, Any] = None) -> str:
        """
        Assess the quality of the last move based on win rate changes
        """
        if not previous_analysis or not current_analysis:
            return "unknown"
        
        # This would normally look at winrate changes
        # For now, we'll return a placeholder
        return "good"  # Placeholder - would analyze winrate change in real implementation
    
    def _extract_strategic_insights(self, analysis: Dict[str, Any]) -> List[str]:
        """
        Extract strategic insights from the analysis
        """
        insights = []
        
        # Look for strategic elements in the analysis
        if analysis.get('moves'):
            top_move = analysis['moves'][0] if analysis['moves'] else None
            if top_move:
                # Analyze the characteristics of the best move
                if 'pv' in top_move and len(top_move['pv']) > 3:
                    insights.append("The position requires deep reading to fully understand.")
                
                if top_move.get('visits', 0) > 5000:
                    insights.append("Katago has high confidence in this position.")
        
        # Add general strategic observations
        if analysis.get('position_eval', {}).get('centipawn', 0) > 50:
            insights.append("Black has a clear advantage based on territory and influence.")
        elif analysis.get('position_eval', {}).get('centipawn', 0) < -50:
            insights.append("White has a clear advantage based on territory and influence.")
        else:
            insights.append("The position is relatively balanced.")
        
        return insights
    
    def _extract_tactical_notes(self, analysis: Dict[str, Any]) -> List[str]:
        """
        Extract tactical observations from the analysis
        """
        notes = []
        
        # Look for tactical elements in the analysis
        if analysis.get('moves'):
            # Examine top few moves for tactical differences
            top_moves = analysis['moves'][:3]
            
            if len(top_moves) > 1:
                best_winrate = top_moves[0].get('winrate', 0)
                second_best = top_moves[1].get('winrate', 0)
                
                if best_winrate - second_best > 10:  # Significant difference
                    notes.append(f"The best move has a clear advantage over alternatives.")
        
        return notes
    
    def _generate_suggestions(self, analysis: Dict[str, Any]) -> List[str]:
        """
        Generate suggestions based on the analysis
        """
        suggestions = []
        
        if analysis.get('moves'):
            top_moves = analysis['moves'][:3]
            if len(top_moves) > 1:
                # Suggest the second best move as an alternative
                second_best = top_moves[1]
                if 'move' in second_best:
                    suggestions.append(f"As an alternative, consider {second_best['move']}")
        
        return suggestions
    
    def _generate_professional_commentary(self, 
                                       current_analysis: Dict[str, Any], 
                                       previous_analysis: Dict[str, Any] = None) -> str:
        """
        Generate professional-level commentary based on the analysis
        """
        commentary_parts = []
        
        # Start with position assessment
        position_assessment = self._assess_position(current_analysis)
        commentary_parts.append(position_assessment)
        
        # Add strategic element
        if current_analysis.get('moves'):
            strategic_element = self._describe_strategic_element(current_analysis['moves'][0])
            commentary_parts.append(strategic_element)
        
        # Add tactical element if applicable
        if current_analysis.get('moves'):
            tactical_element = self._describe_tactical_element(current_analysis['moves'][0])
            if tactical_element:
                commentary_parts.append(tactical_element)
        
        # Add overall assessment
        overall_assessment = self._overall_position_assessment(current_analysis)
        commentary_parts.append(overall_assessment)
        
        return " ".join(commentary_parts)
    
    def _assess_position(self, analysis: Dict[str, Any]) -> str:
        """
        Assess the current position
        """
        centipawn = analysis.get('position_eval', {}).get('centipawn', 0)
        winrate = analysis.get('position_eval', {}).get('winrate', 50.0)
        
        if abs(centipawn) < 30:
            return "The position remains evenly balanced with both sides having reasonable prospects."
        elif centipawn > 0:
            return f"Black has gained a slight advantage of approximately {centipawn/100:.1f} points."
        else:
            return f"White has gained a slight advantage of approximately {abs(centipawn)/100:.1f} points."
    
    def _describe_strategic_element(self, top_move: Dict[str, Any]) -> str:
        """
        Describe the strategic element of the best move
        """
        if not top_move:
            return "The position requires careful consideration of strategic priorities."
        
        # Determine what the move accomplishes strategically
        if 'pv' in top_move and len(top_move['pv']) > 2:
            return "The position demands deep strategic understanding, with the best continuation involving multiple forcing moves."
        else:
            return "The position requires balancing territorial and strategic considerations."
    
    def _describe_tactical_element(self, top_move: Dict[str, Any]) -> str:
        """
        Describe any tactical elements
        """
        if not top_move:
            return ""
        
        visits = top_move.get('visits', 0)
        if visits > 8000:
            return "Katago has thoroughly examined this position and confirms the soundness of the continuation."
        elif visits < 2000:
            return "The position contains subtle tactical elements that require careful reading."
        else:
            return ""
    
    def _overall_position_assessment(self, analysis: Dict[str, Any]) -> str:
        """
        Provide an overall assessment of the position
        """
        moves = analysis.get('moves', [])
        if not moves:
            return "Further analysis would be needed to determine the best plan for both sides."
        
        # Look at the top move's characteristics
        top_move = moves[0]
        winrate = top_move.get('winrate', 50.0)
        
        if winrate > 60:
            return "Black stands better in this complex position."
        elif winrate < 40:
            return "White stands better in this complex position."
        else:
            return "The position remains unclear with chances for both sides."
    
    def generate_move_commentary(self, 
                               move_coords: Tuple[int, int], 
                               katago_analysis: Dict[str, Any],
                               board_state_description: str = "") -> str:
        """
        Generate specific commentary for a particular move
        """
        # Create commentary for a specific move
        if katago_analysis and katago_analysis.get('moves'):
            top_move = katago_analysis['moves'][0] if katago_analysis['moves'] else None
            if top_move:
                # Generate move-specific commentary
                move_notation = self._coords_to_gtp(move_coords)
                
                if top_move.get('move') == move_notation:
                    # The played move matches Katago's top recommendation
                    return f"The move {move_notation} is consistent with professional play, addressing the position's requirements effectively."
                else:
                    # The played move differs from Katago's recommendation
                    expected_move = top_move.get('move', 'the best move')
                    return f"Although {move_notation} is a reasonable move, {expected_move} was considered slightly superior in this position."
        
        # Fallback commentary
        return f"The move {move_coords[0]},{move_coords[1]} contributes to the overall position in a meaningful way."
    
    def _coords_to_gtp(self, coords: Tuple[int, int]) -> str:
        """
        Convert coordinates to GTP notation
        """
        x, y = coords
        if x < 0 or y < 0:
            return "pass"
        
        # Convert to GTP format (letters)
        letters = "ABCDEFGHJKLMNOPQRSTUVWXYZ"  # Note: skipping 'I'
        col = letters[y] if y < 8 else letters[y + 1]  # Adjust for missing 'I'
        row = letters[x] if x < 8 else letters[x + 1]  # Adjust for missing 'I'
        
        return f"{col}{row}"


# Example usage
if __name__ == "__main__":
    interpreter = MoveIntentInterpreter()
    print("Move Intent Interpreter initialized successfully!")
    print("This module interprets Katago analysis and generates professional commentary.")