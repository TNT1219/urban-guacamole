"""
Go Commentary Engine - A professional-level Go/Baduk game analysis and commentary system
Main entry point for the application
"""
import os
import sys
from .board import GoBoard
from .sgf_parser import SGFParser
from .analysis_engine import AnalysisEngine
from .commentary_generator import CommentaryGenerator


class GoCommentarySystem:
    def __init__(self, use_katago=True, katago_path="katago"):
        self.board = GoBoard()
        self.sgf_parser = SGFParser()
        self.analysis_engine = AnalysisEngine(use_katago=use_katago, katago_path=katago_path)
        self.commentary_generator = CommentaryGenerator()
    
    def analyze_game(self, sgf_file_path):
        """Analyze a complete game from SGF file"""
        game_data = self.sgf_parser.parse(sgf_file_path)
        commentary = []
        
        for move_num, move in enumerate(game_data['moves']):
            analysis = self.analysis_engine.analyze_position(
                game_data['board_states'][move_num], 
                move
            )
            comment = self.commentary_generator.generate_commentary(
                analysis, 
                move_num
            )
            commentary.append({
                'move_number': move_num + 1,
                'move': move,
                'analysis': analysis,
                'commentary': comment
            })
        
        return commentary
    
    def analyze_single_position(self, board_state, current_player):
        """Analyze a single position and provide commentary"""
        analysis = self.analysis_engine.analyze_position(board_state, current_player)
        commentary = self.commentary_generator.generate_commentary(analysis, None)
        return {
            'analysis': analysis,
            'commentary': commentary
        }


def main():
    # Example usage
    if len(sys.argv) != 2:
        print("Usage: python -m go_commentary_engine <sgf_file>")
        return
    
    sgf_file = sys.argv[1]
    if not os.path.exists(sgf_file):
        print(f"File {sgf_file} not found")
        return
    
    system = GoCommentarySystem()
    commentary = system.analyze_game(sgf_file)
    
    for item in commentary:
        print(f"Move {item['move_number']}: {item['commentary']}")


if __name__ == "__main__":
    main()