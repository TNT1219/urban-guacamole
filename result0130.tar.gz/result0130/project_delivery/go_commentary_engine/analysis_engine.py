"""
Analysis Engine for the Go Commentary System
Implements the core logic for analyzing Go positions and move intentions
"""
import numpy as np
from typing import Dict, List, Tuple, Any
from .board import GoBoard, Stone
from .katago_interface import KatagoInterface, KatagoAnalysisProcessor
from .move_intent_interpreter import MoveIntentInterpreter


class AnalysisEngine:
    def __init__(self, use_katago=True, katago_path="katago"):
        # Initialize various analysis modules
        self.use_katago = use_katago
        if self.use_katago:
            try:
                self.katago = KatagoInterface(katago_path=katago_path)
                self.katago.start_engine()
                self.katago_processor = KatagoAnalysisProcessor()
                self.move_interpreter = MoveIntentInterpreter()
            except Exception as e:
                print(f"Warning: Could not initialize Katago: {e}")
                print("Falling back to basic analysis engine")
                self.use_katago = False
        
        self.tactical_analyzer = TacticalAnalyzer()
        self.strategic_analyzer = StrategicAnalyzer()
        self.pattern_recognizer = PatternRecognizer()
        self.influence_calculator = InfluenceCalculator()
    
    def analyze_position(self, board: GoBoard, move: Tuple[int, int] = None) -> Dict[str, Any]:
        """
        Analyze a Go position and optionally a specific move
        Returns detailed analysis of the position and move
        """
        # If Katago is available, use it for primary analysis
        if self.use_katago:
            katago_analysis = self._get_katago_analysis(board, move)
        else:
            katago_analysis = None
        
        analysis = {
            'position_evaluation': self._evaluate_position(board),
            'strategic_elements': self._analyze_strategic_elements(board),
            'tactical_situations': self._find_tactical_situations(board),
            'territory_influence': self._analyze_territory_influence(board),
            'move_analysis': None,
            'katago_analysis': katago_analysis
        }
        
        if move is not None:
            analysis['move_analysis'] = self._analyze_move_impact(board, move)
        
        return analysis
    
    def _get_katago_analysis(self, board: GoBoard, move: Tuple[int, int] = None) -> Dict[str, Any]:
        """
        Get analysis from Katago engine
        """
        try:
            # Set up the board position in Katago
            self.katago.clear_board()
            self.katago.board_size(board.size)
            
            # Replay all moves in the game history
            for mv in board.move_history:
                x, y, player = mv
                # Convert coordinates to Katago format (letters)
                vertex = self._coord_to_vertex(x, y)
                color = "B" if player == Stone.BLACK else "W"
                self.katago.play_move(color, vertex)
            
            # If analyzing a specific move, play it
            if move:
                x, y = move
                vertex = self._coord_to_vertex(x, y)
                color = "B" if board.current_player == Stone.BLACK else "W"
                # Analyze the position after the move
                self.katago.play_move(color, vertex)
            
            # Get analysis from Katago
            katago_raw_analysis = self.katago.lz_analyze(moves=10)
            
            # Process the analysis
            processed_analysis = self.katago_processor.parse_kata_analyze(katago_raw_analysis)
            
            return processed_analysis
        except Exception as e:
            print(f"Error getting Katago analysis: {e}")
            return None
    
    def _coord_to_vertex(self, x: int, y: int) -> str:
        """
        Convert numeric coordinates to Katago vertex format (e.g., (3, 3) -> "dd")
        """
        # Convert 0-18 to a-s
        if x < 0 or x > 18 or y < 0 or y > 18:
            return "pass"  # Pass move
        
        # For 19x19 board, 0->a, 1->b, ..., 8->i, 9->j (skip i), 10->k, ...
        letters = "abcdefghjklmnopqrstuvwxyz"
        col_letter = letters[y] if y < 8 else letters[y + 1]  # Skip 'i'
        row_letter = letters[x] if x < 8 else letters[x + 1]  # Skip 'i'
        
        return f"{col_letter}{row_letter}"
    
    def _evaluate_position(self, board: GoBoard) -> Dict[str, float]:
        """
        Evaluate the overall position balance
        """
        # Calculate basic material count
        black_stones = np.sum(board.board == Stone.BLACK.value)
        white_stones = np.sum(board.board == Stone.WHITE.value)
        
        # Calculate captures
        black_score_adj = board.captured_white
        white_score_adj = board.captured_black
        
        # Calculate simple territory approximation
        territory_eval = self._approximate_territory(board)
        
        # Combine factors for position evaluation
        black_advantage = (black_stones + black_score_adj + territory_eval['black_territory']) - \
                         (white_stones + white_score_adj + territory_eval['white_territory'])
        
        return {
            'black_advantage': black_advantage,
            'win_probability': self._convert_to_win_prob(black_advantage),
            'complexity': self._calculate_complexity(board),
            'balance': self._calculate_balance(board)
        }
    
    def _approximate_territory(self, board: GoBoard) -> Dict[str, float]:
        """
        Approximate territory for both sides
        This is a simplified version - real implementation would be much more complex
        """
        # Use influence maps to estimate territory
        influence_map = self.influence_calculator.calculate_influence(board)
        
        black_territory = 0
        white_territory = 0
        neutral_territory = 0
        
        for x in range(board.size):
            for y in range(board.size):
                if board.board[x][y] == Stone.EMPTY.value:
                    if influence_map[x][y]['black_influence'] > influence_map[x][y]['white_influence'] + 10:
                        black_territory += 1
                    elif influence_map[x][y]['white_influence'] > influence_map[x][y]['black_influence'] + 10:
                        white_territory += 1
                    else:
                        neutral_territory += 1
                elif board.board[x][y] == Stone.BLACK.value:
                    black_territory += 1
                else:
                    white_territory += 1
        
        return {
            'black_territory': black_territory,
            'white_territory': white_territory,
            'neutral_territory': neutral_territory
        }
    
    def _convert_to_win_prob(self, advantage: float) -> float:
        """
        Convert positional advantage to winning probability
        Simplified sigmoid-like function
        """
        # This is a very simplified conversion - real implementation would be more nuanced
        prob = 1 / (1 + np.exp(-advantage * 0.2))
        return max(0.01, min(0.99, prob))
    
    def _calculate_complexity(self, board: GoBoard) -> float:
        """
        Calculate how complex/uncertain the position is
        Higher values indicate more complex positions requiring deeper reading
        """
        # Complexity is related to number of reasonable moves and potential tactical sequences
        legal_moves = board.get_legal_moves()
        
        # Estimate complexity based on number of reasonable moves
        # More reasonable moves generally means more complex position
        reasonable_moves = min(len(legal_moves), 50)  # Cap at 50 for normalization
        
        # Factor in the number of unsettled groups
        unsettled_groups = self.tactical_analyzer.count_unsettled_groups(board)
        
        complexity = min(1.0, (reasonable_moves / 30) * 0.6 + (unsettled_groups / 10) * 0.4)
        return complexity
    
    def _calculate_balance(self, board: GoBoard) -> float:
        """
        Calculate how balanced the position is
        0.0 = completely unbalanced, 1.0 = perfectly balanced
        """
        pos_eval = self._evaluate_position(board)
        advantage_abs = abs(pos_eval['black_advantage'])
        
        # More extreme advantages mean less balance
        # Normalize based on typical game values
        balance = max(0.0, 1.0 - min(1.0, advantage_abs / 20.0))
        return balance
    
    def _analyze_strategic_elements(self, board: GoBoard) -> Dict[str, Any]:
        """
        Analyze strategic elements like moyos, territories, frameworks
        """
        # Find potential moyos (large areas of influence)
        moyos = self.strategic_analyzer.find_moyos(board)
        
        # Identify territory vs. influence oriented positions
        territory_influence_balance = self.strategic_analyzer.evaluate_frameworks(board)
        
        # Assess shape and efficiency of groups
        shape_efficiency = self.strategic_analyzer.evaluate_shape_efficiency(board)
        
        return {
            'moyos': moyos,
            'frameworks': territory_influence_balance,
            'shape_efficiency': shape_efficiency,
            'strategic_theme': self._identify_strategic_theme(board)
        }
    
    def _identify_strategic_theme(self, board: GoBoard) -> str:
        """
        Identify the dominant strategic theme of the position
        """
        # Analyze the stage of the game and dominant themes
        total_moves = len(board.move_history)
        
        if total_moves < 30:  # Opening
            return "fuseki"
        elif total_moves < 100:  # Middle game
            return "middle_game_combination"
        else:  # Endgame
            return "endgame_technique"
    
    def _find_tactical_situations(self, board: GoBoard) -> List[Dict[str, Any]]:
        """
        Find tactical situations like ataris, ladders, capturing races
        """
        tactical_situations = []
        
        # Find groups in atari
        groups_in_atari = self.tactical_analyzer.find_groups_in_atari(board)
        for group in groups_in_atari:
            tactical_situations.append({
                'type': 'atari',
                'group': group,
                'urgency': 'high'
            })
        
        # Find potential captures
        potential_captures = self.tactical_analyzer.find_potential_captures(board)
        for capture in potential_captures:
            tactical_situations.append({
                'type': 'potential_capture',
                'target': capture,
                'urgency': 'medium'
            })
        
        # Find ladder situations
        ladder_situations = self.tactical_analyzer.check_ladders(board)
        for ladder in ladder_situations:
            tactical_situations.append({
                'type': 'ladder',
                'details': ladder,
                'urgency': 'high'
            })
        
        return tactical_situations
    
    def _analyze_territory_influence(self, board: GoBoard) -> Dict[str, Any]:
        """
        Analyze territory and influence patterns
        """
        influence_map = self.influence_calculator.calculate_influence(board)
        
        # Calculate territory estimates
        territory_estimate = self._approximate_territory(board)
        
        # Identify contested areas
        contested_areas = self.influence_calculator.find_contested_areas(influence_map)
        
        return {
            'influence_map': influence_map,
            'territory_estimate': territory_estimate,
            'contested_areas': contested_areas,
            'safety_assessment': self._assess_group_safety(board)
        }
    
    def _assess_group_safety(self, board: GoBoard) -> Dict[str, List]:
        """
        Assess the safety of groups on the board
        """
        safe_groups = []
        unsafe_groups = []
        
        # This would involve more complex life and death analysis
        # For now, we'll use a simplified approach
        for x in range(board.size):
            for y in range(board.size):
                if board.board[x][y] != Stone.EMPTY.value:
                    # Simplified safety assessment based on liberties and surroundings
                    if self._is_group_safe(board, x, y):
                        safe_groups.append((x, y))
                    else:
                        unsafe_groups.append((x, y))
        
        return {
            'safe_groups': safe_groups,
            'unsafe_groups': unsafe_groups
        }
    
    def _is_group_safe(self, board: GoBoard, x: int, y: int) -> bool:
        """
        Simplified group safety assessment
        """
        # This would require more sophisticated life and death analysis
        # For now, return a basic assessment
        color = board.board[x][y]
        if color == Stone.EMPTY.value:
            return True
        
        # Get the group
        group = self._get_group(board, x, y, color)
        
        # Count liberties for the group
        liberties = self._count_group_liberties(board, group)
        
        # Basic safety heuristic: groups with more than 2 liberties are safer
        return liberties > 2
    
    def _get_group(self, board: GoBoard, x: int, y: int, color: int) -> List[Tuple[int, int]]:
        """
        Get the group containing the stone at (x, y)
        """
        visited = set()
        stack = [(x, y)]
        group = []
        
        while stack:
            cx, cy = stack.pop()
            if (cx, cy) in visited:
                continue
            
            visited.add((cx, cy))
            group.append((cx, cy))
            
            for dx, dy in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                nx, ny = cx + dx, cy + dy
                if (0 <= nx < board.size and 0 <= ny < board.size and 
                    board.board[nx][ny] == color and (nx, ny) not in visited):
                    stack.append((nx, ny))
        
        return group
    
    def _count_group_liberties(self, board: GoBoard, group: List[Tuple[int, int]]) -> int:
        """
        Count liberties for a group of stones
        """
        liberties = set()
        
        for x, y in group:
            for dx, dy in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                nx, ny = x + dx, y + dy
                if (0 <= nx < board.size and 0 <= ny < board.size and 
                    board.board[nx][ny] == Stone.EMPTY.value):
                    liberties.add((nx, ny))
        
        return len(liberties)
    
    def _analyze_move_impact(self, board: GoBoard, move: Tuple[int, int]) -> Dict[str, Any]:
        """
        Analyze the impact and intention of a specific move
        """
        # Create a copy of the board to simulate the move
        sim_board = board.copy()
        
        try:
            # Play the move on the simulation board
            sim_board.play_move(move[0], move[1])
            
            # Compare position evaluations before and after
            before_eval = self._evaluate_position(board)
            after_eval = self._evaluate_position(sim_board)
            
            # Determine the impact of the move
            eval_change = after_eval['black_advantage'] - before_eval['black_advantage']
            if board.current_player == Stone.WHITE:
                # If white played, we need to invert the change
                eval_change = -eval_change
            
            # Analyze what the move accomplishes
            move_purpose = self._determine_move_purpose(board, move, sim_board)
            
            # Check if this move addresses any tactical threats
            tactical_response = self._check_tactical_response(board, move)
            
            # Check if this move creates new tactical opportunities
            tactical_creation = self._check_tactical_creation(sim_board, move)
            
            return {
                'eval_impact': eval_change,
                'move_purpose': move_purpose,
                'tactical_response': tactical_response,
                'tactical_creation': tactical_creation,
                'strategic_alignment': self._check_strategic_alignment(board, move),
                'pattern_match': self.pattern_recognizer.match_pattern(board, move)
            }
        except Exception as e:
            # If there was an error making the move, return minimal info
            return {
                'eval_impact': 0,
                'move_purpose': 'invalid_move',
                'error': str(e)
            }


class TacticalAnalyzer:
    """
    Handles tactical analysis of the position
    """
    def __init__(self):
        pass
    
    def find_groups_in_atari(self, board: GoBoard) -> List[Dict[str, Any]]:
        """
        Find all groups that are in atari (have only one liberty)
        """
        groups_in_atari = []
        
        # Check each non-empty intersection
        for x in range(board.size):
            for y in range(board.size):
                if board.board[x][y] != Stone.EMPTY.value:
                    # Check if this stone is part of a group in atari
                    color = board.board[x][y]
                    
                    # Get the full group
                    group = self._get_group(board, x, y, color)
                    
                    # Check if the group is in atari
                    liberties = self._count_group_liberties(board, group)
                    if liberties == 1:
                        # Only add if we haven't already added this group
                        if not any(g['stones'] == group for g in groups_in_atari):
                            liberty_pos = self._get_liberty_position(board, group)
                            groups_in_atari.append({
                                'stones': group,
                                'color': 'black' if color == Stone.BLACK.value else 'white',
                                'liberty': liberty_pos
                            })
        
        return groups_in_atari
    
    def _get_group(self, board: GoBoard, x: int, y: int, color: int) -> List[Tuple[int, int]]:
        """
        Get the group containing the stone at (x, y)
        """
        visited = set()
        stack = [(x, y)]
        group = []
        
        while stack:
            cx, cy = stack.pop()
            if (cx, cy) in visited:
                continue
            
            visited.add((cx, cy))
            group.append((cx, cy))
            
            for dx, dy in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                nx, ny = cx + dx, cy + dy
                if (0 <= nx < board.size and 0 <= ny < board.size and 
                    board.board[nx][ny] == color and (nx, ny) not in visited):
                    stack.append((nx, ny))
        
        return group
    
    def _count_group_liberties(self, board: GoBoard, group: List[Tuple[int, int]]) -> int:
        """
        Count liberties for a group of stones
        """
        liberties = set()
        
        for x, y in group:
            for dx, dy in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                nx, ny = x + dx, y + dy
                if (0 <= nx < board.size and 0 <= ny < board.size and 
                    board.board[nx][ny] == Stone.EMPTY.value):
                    liberties.add((nx, ny))
        
        return len(liberties)
    
    def _get_liberty_position(self, board: GoBoard, group: List[Tuple[int, int]]) -> Tuple[int, int]:
        """
        Get the position of the single liberty for a group in atari
        """
        for x, y in group:
            for dx, dy in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                nx, ny = x + dx, y + dy
                if (0 <= nx < board.size and 0 <= ny < board.size and 
                    board.board[nx][ny] == Stone.EMPTY.value):
                    return (nx, ny)
        
        return None
    
    def find_potential_captures(self, board: GoBoard) -> List[Dict[str, Any]]:
        """
        Find moves that would capture opponent stones
        """
        potential_captures = []
        
        # Check each empty intersection
        for x in range(board.size):
            for y in range(board.size):
                if board.board[x][y] == Stone.EMPTY.value:
                    # Simulate placing a stone of the current player's color
                    current_color = board.current_player
                    opponent_color = Stone.WHITE if current_color == Stone.BLACK else Stone.BLACK
                    
                    # Temporarily place the stone
                    temp_board = board.board.copy()
                    temp_board[x][y] = current_color.value
                    
                    # Check if this captures any opponent stones
                    captured = self._check_captures(temp_board, x, y, opponent_color.value)
                    
                    if captured:
                        potential_captures.append({
                            'move': (x, y),
                            'captures': captured,
                            'captured_count': len(captured)
                        })
        
        return potential_captures
    
    def _check_captures(self, board: np.ndarray, x: int, y: int, opponent_color: int) -> List[Tuple[int, int]]:
        """
        Check if placing a stone at (x, y) captures opponent stones
        """
        captured = []
        
        # Check adjacent opponent groups
        for dx, dy in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
            nx, ny = x + dx, y + dy
            if (0 <= nx < len(board) and 0 <= ny < len(board[0]) and 
                board[nx][ny] == opponent_color):
                
                # Get the group
                group = self._get_opponent_group(board, nx, ny, opponent_color)
                
                # Check if the group has no liberties after our move
                if self._group_has_no_liberties_after_move(board, group, x, y):
                    captured.extend(group)
        
        return captured
    
    def _get_opponent_group(self, board: np.ndarray, x: int, y: int, color: int) -> List[Tuple[int, int]]:
        """
        Get opponent group starting from (x, y)
        """
        visited = set()
        stack = [(x, y)]
        group = []
        
        while stack:
            cx, cy = stack.pop()
            if (cx, cy) in visited:
                continue
            
            visited.add((cx, cy))
            group.append((cx, cy))
            
            for dx, dy in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                nx, ny = cx + dx, cy + dy
                if (0 <= nx < len(board) and 0 <= ny < len(board[0]) and 
                    board[nx][ny] == color and (nx, ny) not in visited):
                    stack.append((nx, ny))
        
        return group
    
    def _group_has_no_liberties_after_move(self, board: np.ndarray, group: List[Tuple[int, int]], x: int, y: int) -> bool:
        """
        Check if a group has no liberties after a move at (x, y)
        """
        # Temporarily mark the move location as occupied
        original_val = board[x][y]
        board[x][y] = 3  # Temporarily mark as occupied
        
        # Count liberties of the group
        liberties = set()
        for gx, gy in group:
            for dx, dy in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                nx, ny = gx + dx, gy + dy
                if (0 <= nx < len(board) and 0 <= ny < len(board[0]) and 
                    board[nx][ny] == 0):
                    liberties.add((nx, ny))
        
        # Restore original value
        board[x][y] = original_val
        
        return len(liberties) == 0
    
    def check_ladders(self, board: GoBoard) -> List[Dict[str, Any]]:
        """
        Check for ladder situations
        """
        # Ladder detection is quite complex and requires looking ahead
        # For now, we'll implement a basic version that identifies potential ladders
        # based on groups in atari with certain escape routes blocked
        ladders = []
        
        # Look for groups in atari
        groups_in_atari = self.find_groups_in_atari(board)
        
        for group_info in groups_in_atari:
            group = group_info['stones']
            liberty = group_info['liberty']
            color = group_info['color']
            
            # Check if escaping the atari leads to another atari situation
            if self._would_escape_lead_to_ladder(board, liberty, group, color):
                ladders.append({
                    'group': group,
                    'liberty': liberty,
                    'color': color,
                    'escape_route_blocked': True
                })
        
        return ladders
    
    def _would_escape_lead_to_ladder(self, board: GoBoard, liberty: Tuple[int, int], 
                                   group: List[Tuple[int, int]], color: str) -> bool:
        """
        Check if escaping from atari would lead to a ladder
        """
        # This is a simplified check - full ladder detection requires deep reading
        # We'll check if the escape move puts the escaping stone in atari
        # and if that continues the pattern
        opponent_color = Stone.WHITE if color == 'black' else Stone.BLACK
        
        # Simulate the escape move
        sim_board = board.copy()
        try:
            sim_board.play_move(liberty[0], liberty[1])
            
            # After the escape, see if the newly placed stone is in atari
            # and if the surrounding situation continues the ladder pattern
            # This is a simplified check - a full implementation would be much more complex
            escaped_group = self._get_group(sim_board, liberty[0], liberty[1], 
                                         opponent_color.value if color == 'black' else Stone.BLACK.value)
            
            return self._count_group_liberties(sim_board, escaped_group) == 1
        except:
            return False
    
    def count_unsettled_groups(self, board: GoBoard) -> int:
        """
        Count groups that appear to be unsettled (potentially alive or dead)
        """
        # This is a simplified estimation
        # A full implementation would require life and death solving
        unsettled_count = 0
        
        # For now, consider groups with fewer than 4 liberties as potentially unsettled
        for x in range(board.size):
            for y in range(board.size):
                if board.board[x][y] != Stone.EMPTY.value:
                    color = board.board[x][y]
                    group = self._get_group(board, x, y, color)
                    
                    # Only count each group once
                    if group and group[0] == (x, y):  # Only process if this is the first stone of the group
                        liberties = self._count_group_liberties(board, group)
                        if liberties <= 4:
                            unsettled_count += 1
        
        return unsettled_count


class StrategicAnalyzer:
    """
    Handles strategic analysis of the position
    """
    def __init__(self):
        pass
    
    def find_moyos(self, board: GoBoard) -> List[Dict[str, Any]]:
        """
        Find moyos (large frameworks/potential territories)
        """
        # Simplified moyo detection algorithm
        moyos = []
        
        # This would typically involve analyzing influence maps and finding large areas
        # where one player has strong influence but no stones yet
        influence_map = InfluenceCalculator().calculate_influence(board)
        
        # Look for large connected areas with high influence
        visited = set()
        for x in range(board.size):
            for y in range(board.size):
                if (x, y) not in visited and board.board[x][y] == Stone.EMPTY.value:
                    influence = influence_map[x][y]
                    
                    # Check if this is part of a large area with consistent influence
                    if influence['black_influence'] > influence['white_influence'] * 2 or \
                       influence['white_influence'] > influence['black_influence'] * 2:
                        
                        area = self._find_connected_influence_area(
                            board, influence_map, x, y, visited
                        )
                        
                        if len(area) > 15:  # Consider areas larger than 15 points as moyos
                            dominant_color = 'black' if influence['black_influence'] > influence['white_influence'] else 'white'
                            moyos.append({
                                'area': area,
                                'dominant_color': dominant_color,
                                'size': len(area),
                                'center_of_mass': self._calculate_center_of_mass(area)
                            })
        
        return moyos
    
    def _find_connected_influence_area(self, board: GoBoard, influence_map: np.ndarray,
                                     start_x: int, start_y: int, visited: set) -> List[Tuple[int, int]]:
        """
        Find connected area of consistent influence
        """
        area = []
        stack = [(start_x, start_y)]
        
        while stack:
            x, y = stack.pop()
            
            if (x, y) in visited or board.board[x][y] != Stone.EMPTY.value:
                continue
            
            visited.add((x, y))
            influence = influence_map[x][y]
            
            # Check if influence is consistently dominated by one side
            if (influence['black_influence'] > influence['white_influence'] * 1.5 or
                influence['white_influence'] > influence['black_influence'] * 1.5):
                
                area.append((x, y))
                
                # Add neighbors to check
                for dx, dy in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                    nx, ny = x + dx, y + dy
                    if (0 <= nx < board.size and 0 <= ny < board.size and
                        (nx, ny) not in visited):
                        stack.append((nx, ny))
        
        return area
    
    def _calculate_center_of_mass(self, area: List[Tuple[int, int]]) -> Tuple[float, float]:
        """
        Calculate center of mass of an area
        """
        if not area:
            return (0, 0)
        
        sum_x = sum(p[0] for p in area)
        sum_y = sum(p[1] for p in area)
        
        return (sum_x / len(area), sum_y / len(area))
    
    def evaluate_frameworks(self, board: GoBoard) -> Dict[str, Any]:
        """
        Evaluate territorial vs. influential positions
        """
        # Analyze how the position is structured in terms of territory vs. influence
        influence_map = InfluenceCalculator().calculate_influence(board)
        
        # Count territory-like areas vs influence-like areas
        territory_black = 0
        territory_white = 0
        influence_black = 0
        influence_white = 0
        
        for x in range(board.size):
            for y in range(board.size):
                influence = influence_map[x][y]
                
                if board.board[x][y] == Stone.BLACK.value:
                    territory_black += 1
                elif board.board[x][y] == Stone.WHITE.value:
                    territory_white += 1
                else:
                    # Empty point - evaluate based on influence
                    if influence['black_influence'] > influence['white_influence']:
                        if influence['black_influence'] > 15:
                            territory_black += 0.5  # Potential territory
                        else:
                            influence_black += 1
                    else:
                        if influence['white_influence'] > 15:
                            territory_white += 0.5  # Potential territory
                        else:
                            influence_white += 1
        
        return {
            'black': {
                'territory_oriented': territory_black,
                'influence_oriented': influence_black
            },
            'white': {
                'territory_oriented': territory_white,
                'influence_oriented': influence_white
            },
            'style': 'balanced' if abs((territory_black + territory_white) - (influence_black + influence_white)) < 20 
                     else 'territorial' if (territory_black + territory_white) > (influence_black + influence_white)
                     else 'influential'
        }
    
    def evaluate_shape_efficiency(self, board: GoBoard) -> Dict[str, float]:
        """
        Evaluate the efficiency of stone placement (shape)
        """
        # This would involve recognizing good and bad shapes
        # For now, we'll implement a simplified version based on spacing and connections
        black_efficiency = self._evaluate_player_shape_efficiency(board, Stone.BLACK)
        white_efficiency = self._evaluate_player_shape_efficiency(board, Stone.WHITE)
        
        return {
            'black_efficiency': black_efficiency,
            'white_efficiency': white_efficiency,
            'efficiency_difference': black_efficiency - white_efficiency
        }
    
    def _evaluate_player_shape_efficiency(self, board: GoBoard, player: Stone) -> float:
        """
        Evaluate the shape efficiency for a player
        """
        # Simplified efficiency measure based on stone spacing and connections
        player_stones = []
        
        for x in range(board.size):
            for y in range(board.size):
                if board.board[x][y] == player.value:
                    player_stones.append((x, y))
        
        if not player_stones:
            return 0.0
        
        # Calculate average distance between adjacent stones
        total_efficiency = 0.0
        stone_count = len(player_stones)
        
        for i, (x1, y1) in enumerate(player_stones):
            # Check for adjacent friendly stones
            adjacent_friends = 0
            for dx, dy in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                nx, ny = x1 + dx, y1 + dy
                if (0 <= nx < board.size and 0 <= ny < board.size and
                    board.board[nx][ny] == player.value):
                    adjacent_friends += 1
            
            # Efficiency increases with good connections but decreases with overcrowding
            if adjacent_friends <= 2:  # Good connectivity without overcrowding
                total_efficiency += 1.0
            elif adjacent_friends == 3:  # Still acceptable
                total_efficiency += 0.7
            else:  # Potentially inefficient overcrowding
                total_efficiency += 0.3
        
        return total_efficiency / stone_count if stone_count > 0 else 0.0


class PatternRecognizer:
    """
    Recognizes Go patterns and josekis
    """
    def __init__(self):
        # Load known patterns (in a real implementation, this would load from a database)
        self.common_patterns = self._load_common_patterns()
    
    def _load_common_patterns(self):
        """
        Load common Go patterns (simplified for this example)
        """
        return {
            'corner_enclosure': {
                'description': 'Corner enclosure pattern',
                'commonality': 0.8
            },
            'sanrensei': {
                'description': 'Three-star formation',
                'commonality': 0.6
            },
            'small_kidogma': {
                'description': 'Small kidogma (3-4 point invasion)',
                'commonality': 0.9
            },
            'large_kidogma': {
                'description': 'Large kidogma (4-4 point approach)',
                'commonality': 0.85
            },
            'cutting_point': {
                'description': 'Common cutting point',
                'commonality': 0.7
            }
        }
    
    def match_pattern(self, board: GoBoard, move: Tuple[int, int]) -> Dict[str, Any]:
        """
        Check if a move matches any known patterns
        """
        # This is a simplified pattern matching algorithm
        # In reality, this would use more sophisticated techniques like convolutional neural networks
        # or pattern databases with fuzzy matching
        
        # Check local 5x5 pattern around the move
        local_pattern = self._extract_local_pattern(board, move[0], move[1])
        
        # Match against known patterns
        matches = []
        for pattern_name, pattern_info in self.common_patterns.items():
            if self._pattern_matches(local_pattern, pattern_name):
                matches.append({
                    'name': pattern_name,
                    'confidence': pattern_info['commonality'],
                    'description': pattern_info['description'],
                    'professional_frequency': pattern_info['commonality']
                })
        
        return {
            'matches': matches,
            'local_pattern': local_pattern,
            'novelty_score': 1.0 - max([m['confidence'] for m in matches], default=0)
        }
    
    def _extract_local_pattern(self, board: GoBoard, x: int, y: int) -> List[List[int]]:
        """
        Extract a local pattern around a point
        """
        # Create a 5x5 grid centered on (x, y), padded with empty space if needed
        pattern = []
        for dx in range(-2, 3):
            row = []
            for dy in range(-2, 3):
                nx, ny = x + dx, y + dy
                if 0 <= nx < board.size and 0 <= ny < board.size:
                    row.append(board.board[nx][ny])
                else:
                    row.append(Stone.EMPTY.value)  # Treat outside board as empty
            pattern.append(row)
        
        return pattern
    
    def _pattern_matches(self, local_pattern: List[List[int]], pattern_name: str) -> bool:
        """
        Check if a local pattern matches a known pattern
        """
        # Simplified pattern matching - in reality this would be much more sophisticated
        # This is just a placeholder implementation
        return False  # Actual implementation would depend on the specific pattern


class InfluenceCalculator:
    """
    Calculates influence maps for the board
    """
    def __init__(self):
        pass
    
    def calculate_influence(self, board: GoBoard) -> np.ndarray:
        """
        Calculate influence map for the entire board
        """
        influence_map = np.zeros((board.size, board.size), dtype=[('black_influence', 'f4'), ('white_influence', 'f4')])
        
        for x in range(board.size):
            for y in range(board.size):
                if board.board[x][y] == Stone.EMPTY.value:
                    # Calculate influence from nearby stones
                    black_inf, white_inf = self._calculate_point_influence(board, x, y)
                    influence_map[x][y] = (black_inf, white_inf)
                else:
                    # Stones have maximum influence of their own color
                    if board.board[x][y] == Stone.BLACK.value:
                        influence_map[x][y] = (100.0, 0.0)
                    else:
                        influence_map[x][y] = (0.0, 100.0)
        
        return influence_map
    
    def _calculate_point_influence(self, board: GoBoard, x: int, y: int) -> Tuple[float, float]:
        """
        Calculate influence at a specific point (x, y)
        """
        black_influence = 0.0
        white_influence = 0.0
        
        # Calculate influence from all stones on the board
        # Using inverse square law with exponential decay
        for bx in range(board.size):
            for by in range(board.size):
                if board.board[bx][by] != Stone.EMPTY.value:
                    dist_sq = (x - bx)**2 + (y - by)**2
                    if dist_sq == 0:
                        continue  # Skip the point itself
                    
                    distance = dist_sq ** 0.5
                    # Influence decreases with distance
                    influence = max(0, 50.0 - distance * 5)  # Linear decay model
                    
                    if board.board[bx][by] == Stone.BLACK.value:
                        black_influence += influence
                    else:
                        white_influence += influence
        
        # Normalize influence values
        black_influence = min(100.0, black_influence)
        white_influence = min(100.0, white_influence)
        
        return black_influence, white_influence
    
    def find_contested_areas(self, influence_map: np.ndarray) -> List[Dict[str, Any]]:
        """
        Find areas where both players have significant influence
        """
        contested_areas = []
        
        # Look for points where both players have substantial influence
        for x in range(len(influence_map)):
            for y in range(len(influence_map[0])):
                black_inf = influence_map[x][y]['black_influence']
                white_inf = influence_map[x][y]['white_influence']
                
                # Consider it contested if both have significant influence (>20)
                if black_inf > 20 and white_inf > 20:
                    difference = abs(black_inf - white_inf)
                    
                    # Only consider it highly contested if the difference is not too large
                    if difference < max(black_inf, white_inf) * 0.7:
                        contested_areas.append({
                            'position': (x, y),
                            'black_influence': black_inf,
                            'white_influence': white_inf,
                            'difference': difference,
                            'balance': 1 - (difference / max(black_inf, white_inf))
                        })
        
        return contested_areas