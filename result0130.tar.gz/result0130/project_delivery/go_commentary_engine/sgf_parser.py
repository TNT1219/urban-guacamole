"""
SGF (Smart Game Format) Parser for Go games
Handles reading and parsing SGF files to extract game information
"""
import re
from typing import Dict, List, Tuple, Any


class SGFParser:
    def __init__(self):
        self.properties = {}
        self.moves = []
        self.annotations = []
    
    def parse(self, sgf_content: str) -> Dict[str, Any]:
        """
        Parse SGF content and return structured game data
        """
        if isinstance(sgf_content, str) and sgf_content.startswith('http'):
            # If it's a URL, fetch the content
            import urllib.request
            with urllib.request.urlopen(sgf_content) as response:
                sgf_content = response.read().decode('utf-8')
        elif isinstance(sgf_content, str) and not sgf_content.startswith('('):
            # If it's a file path, read the file
            with open(sgf_content, 'r', encoding='utf-8') as f:
                sgf_content = f.read()
        
        # Clean up the SGF content
        sgf_content = self._clean_sgf(sgf_content)
        
        # Extract properties
        self.properties = self._parse_properties(sgf_content)
        
        # Extract moves and variations
        self.moves = self._parse_moves(sgf_content)
        
        return {
            'properties': self.properties,
            'moves': self.moves,
            'board_states': self._generate_board_states()
        }
    
    def _clean_sgf(self, sgf_content: str) -> str:
        """
        Clean SGF content by removing comments and formatting issues
        """
        # Remove comments and unnecessary whitespace
        sgf_content = re.sub(r'\n\s*', '', sgf_content)
        sgf_content = re.sub(r';(?=\s*[A-Z])', ';', sgf_content)  # Clean up semicolons
        return sgf_content.strip()
    
    def _parse_properties(self, sgf_content: str) -> Dict[str, str]:
        """
        Parse SGF properties like player names, result, etc.
        """
        properties = {}
        
        # Pattern to match property identifiers followed by values
        prop_pattern = r'([A-Z]+)\[([^\[\]]*(?:\[[^\[\]]*\][^\[\]]*)*)\]'
        matches = re.findall(prop_pattern, sgf_content)
        
        for prop_id, value in matches:
            # Remove any remaining brackets from value
            value = re.sub(r'\[|\]', '', value)
            properties[prop_id] = value
        
        return properties
    
    def _parse_moves(self, sgf_content: str) -> List[Dict[str, Any]]:
        """
        Parse moves from SGF content
        """
        moves = []
        
        # Find all sequences inside parentheses
        sequence_pattern = r'\(([^()]*(?:\([^()]*\)[^()]*)*)\)'
        sequences = re.findall(sequence_pattern, sgf_content)
        
        for seq in sequences:
            # Find all move properties (B for Black, W for White)
            move_pattern = r';([BW])((?:\[[^\[\]]+\])+)(?=[;)])'
            move_matches = re.findall(move_pattern, seq)
            
            for color, coords_str in move_matches:
                # Extract coordinates
                coord_match = re.search(r'\[([a-z]{2}|[A-Z]{2}|--)?\]', coords_str)
                if coord_match:
                    coord = coord_match.group(1)
                    if coord and coord != '--':
                        # Convert coordinate from SGF format (lowercase letters) to standard
                        x, y = self._sgf_coord_to_int(coord)
                        moves.append({
                            'color': color,
                            'coordinate': coord,
                            'x': x,
                            'y': y
                        })
        
        return moves
    
    def _sgf_coord_to_int(self, coord: str) -> Tuple[int, int]:
        """
        Convert SGF coordinate (two lowercase letters) to integer coordinates
        """
        if len(coord) != 2:
            return (-1, -1)
        
        col_char, row_char = coord[0], coord[1]
        x = ord(row_char) - ord('a')  # Column (0-18 for 19x19)
        y = ord(col_char) - ord('a')  # Row (0-18 for 19x19)
        
        return (x, y)
    
    def _generate_board_states(self) -> List[Any]:
        """
        Generate board states for each move (placeholder for now)
        """
        # This would generate a series of board states after each move
        # For now, returning empty list - will implement properly later
        return []


def example_usage():
    """
    Example of how to use the SGF parser
    """
    sample_sgf = "(;FF[4]GM[1]SZ[19]PB[Murakawa Daisuke]PW[Iyama Yuta]KM[6.5]HA[0]RE[W+1.5];B[qd];W[dd];B[pq];W[dq];B[fc])"
    
    parser = SGFParser()
    game_data = parser.parse(sample_sgf)
    
    print("Properties:", game_data['properties'])
    print("Moves:", game_data['moves'])
    
    return game_data


if __name__ == "__main__":
    example_usage()