"""
Katago Interface for Go Commentary Engine
Handles communication with the Katago engine via GTP protocol
"""
import subprocess
import threading
import queue
import time
import re
from typing import Optional, Dict, List, Tuple


class KatagoInterface:
    def __init__(self, katago_path: str = "katago", model_path: str = "", config_path: str = ""):
        self.katago_path = katago_path
        self.model_path = model_path
        self.config_path = config_path
        self.process: Optional[subprocess.Popen] = None
        self.output_queue = queue.Queue()
        self.lock = threading.Lock()
        
    def start_engine(self):
        """Start the Katago engine process"""
        cmd = [self.katago_path, "gtp"]
        if self.model_path:
            cmd.extend(["-model", self.model_path])
        if self.config_path:
            cmd.extend(["-config", self.config_path])
            
        self.process = subprocess.Popen(
            cmd,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            universal_newlines=True,
            bufsize=1
        )
        
        # Start output reader thread
        self.reader_thread = threading.Thread(target=self._read_output, daemon=True)
        self.reader_thread.start()
        
        # Initialize GTP
        self._send_command("protocol_version")
        self._send_command("name")
        self._send_command("version")
        
    def _read_output(self):
        """Read output from Katago process"""
        while self.process and self.process.poll() is None:
            try:
                line = self.process.stdout.readline()
                if line:
                    self.output_queue.put(line.strip())
            except:
                break
                
    def _send_command(self, command: str) -> str:
        """Send command to Katago and return response"""
        with self.lock:
            if not self.process:
                raise Exception("Katago process not started")
                
            self.process.stdin.write(command + "\n")
            self.process.stdin.flush()
            
            # Wait for response
            response_lines = []
            while True:
                try:
                    line = self.output_queue.get(timeout=10.0)
                    if line == "":
                        continue
                    response_lines.append(line)
                    # Response ends with a line that doesn't start with =
                    if line.startswith("=") or line.startswith("?"):
                        break
                except queue.Empty:
                    raise TimeoutError(f"Timeout waiting for Katago response to: {command}")
                    
            # Process response
            if response_lines and response_lines[-1].startswith("="):
                # Return the actual response (without the = prefix)
                response = " ".join(response_lines[:-1] + [response_lines[-1][1:]]).strip()
                return response
            elif response_lines and response_lines[-1].startswith("?"):
                # Error response
                error_msg = " ".join(response_lines[:-1] + [response_lines[-1][1:]]).strip()
                raise Exception(f"Katago error: {error_msg}")
            else:
                raise Exception(f"Unexpected response from Katago: {response_lines}")
    
    def board_size(self, size: int = 19):
        """Set board size"""
        self._send_command(f"boardsize {size}")
        
    def clear_board(self):
        """Clear the board"""
        self._send_command("clear_board")
        
    def play_move(self, color: str, vertex: str):
        """Play a move"""
        self._send_command(f"play {color} {vertex}")
        
    def genmove(self, color: str) -> str:
        """Generate a move for the given color"""
        return self._send_command(f"genmove {color}")
        
    def kata_analyze(self, moves: int = 10, analysis_time: float = 1.0) -> str:
        """Get Katago's analysis using the kata-analyze command"""
        return self._send_command(f"kata-analyze {moves} {analysis_time}")
        
    def lz_analyze(self, moves: int = 10) -> str:
        """Get analysis using LZ-style analysis"""
        return self._send_command(f"lz-analyze {moves}")
        
    def final_score(self) -> str:
        """Get the final score"""
        return self._send_command("final_score")
        
    def quit(self):
        """Quit the Katago engine"""
        if self.process:
            self._send_command("quit")
            self.process.terminate()
            self.process = None


class KatagoAnalysisProcessor:
    """
    Processes Katago's analysis output and extracts meaningful information
    """
    def __init__(self):
        pass
        
    def parse_kata_analyze(self, analyze_output: str) -> Dict:
        """
        Parse Katago's kata-analyze output and extract relevant information
        """
        analysis = {
            'moves': [],
            'position_eval': {},
            'winrate_graph': [],
            'pv_sequence': []
        }
        
        lines = analyze_output.split('\n')
        for line in lines:
            line = line.strip()
            if line.startswith('info move'):
                # Parse individual move analysis
                move_info = self._parse_move_info(line)
                if move_info:
                    analysis['moves'].append(move_info)
            elif 'cp' in line:
                # Parse position evaluation (centipawn)
                cp_match = re.search(r'cp\s+([-\d]+)', line)
                if cp_match:
                    analysis['position_eval']['centipawn'] = int(cp_match.group(1))
            elif 'winrate' in line:
                # Parse winrate
                wr_match = re.search(r'winrate\s+([\d.]+)', line)
                if wr_match:
                    analysis['position_eval']['winrate'] = float(wr_match.group(1))
        
        return analysis
    
    def _parse_move_info(self, line: str) -> Optional[Dict]:
        """
        Parse individual move analysis from Katago output
        """
        move_data = {}
        
        # Extract move
        move_match = re.search(r'move\s+(\w+)', line)
        if move_match:
            move_data['move'] = move_match.group(1)
        
        # Extract visits
        visits_match = re.search(r'visits\s+(\d+)', line)
        if visits_match:
            move_data['visits'] = int(visits_match.group(1))
        
        # Extract winrate
        winrate_match = re.search(r'winrate\s+([\d.]+)', line)
        if winrate_match:
            move_data['winrate'] = float(winrate_match.group(1))
        
        # Extract prior
        prior_match = re.search(r'prior\s+([\d.]+)', line)
        if prior_match:
            move_data['prior'] = float(prior_match.group(1))
        
        # Extract lcb
        lcb_match = re.search(r'lcb\s+([\d.]+)', line)
        if lcb_match:
            move_data['lcb'] = float(lcb_match.group(1))
        
        # Extract order
        order_match = re.search(r'order\s+(\d+)', line)
        if order_match:
            move_data['order'] = int(order_match.group(1))
        
        # Extract pv (principal variation)
        pv_match = re.search(r'pv\s+([a-zA-Z\d\s]+)', line)
        if pv_match:
            move_data['pv'] = pv_match.group(1).strip().split()
        
        return move_data if move_data.get('move') else None


# Example usage
if __name__ == "__main__":
    # Example of how to use the Katago interface
    print("Katago Interface - This module interfaces with the Katago engine")
    print("To use this, you need to have Katago installed on your system")