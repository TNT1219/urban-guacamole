"""
Commentary Generator for the Go Commentary System
Transforms analysis data into natural language commentary
resembling professional Go commentary
"""
from typing import Dict, List, Any, Tuple
import random
from .move_intent_interpreter import MoveIntentInterpreter


class CommentaryGenerator:
    def __init__(self):
        # Professional Go terminology and phrases
        self.terms = self._load_go_terms()
        self.commentary_templates = self._load_commentary_templates()
        self.style_guides = self._load_style_guides()
        self.intent_interpreter = MoveIntentInterpreter()
    
    def _load_go_terms(self) -> Dict[str, List[str]]:
        """
        Load professional Go terminology organized by concept
        """
        return {
            'opening': [
                'fuseki', 'enclosure', 'approach', 'invade', 'extend', 
                'shoulder hit', 'high approach', 'low approach'
            ],
            'middle_game': [
                'fighting', 'attacking', 'defending', 'cutting', 'connecting',
                'life and death', 'semeai', 'aji', 'thickness', 'lightness'
            ],
            'endgame': [
                'yose', 'gote', 'sente', 'reverse sente', 'miai', 'tsuke',
                'boundary', 'mutual damage'
            ],
            'shape': [
                'good shape', 'bad shape', 'empty triangle', 'bamboo joint',
                'one point jump', 'two point jump', 'diagonal', 'dogzuki'
            ],
            'evaluation': [
                'Black is ahead', 'White is ahead', 'Even position', 
                'Complicated position', 'Sharp position', 'Quiet position'
            ]
        }
    
    def _load_commentary_templates(self) -> Dict[str, List[str]]:
        """
        Load commentary templates for different types of analysis
        """
        return {
            'move_purpose': [
                "The purpose of this move is to {purpose}.",
                "This move aims to {purpose}, which is a common idea in this position.",
                "A solid move that {purpose}.",
                "This move {purpose}, strengthening the position on the {side}.",
                "The idea behind this move is to {purpose}, which shows good understanding of the position."
            ],
            'tactical': [
                "{player} must respond to the threat, and this move effectively {response}.",
                "This move addresses the immediate tactical concern by {response}.",
                "A necessary defensive move to prevent {threat}.",
                "The position demanded a response to {threat}, and this move handles it well."
            ],
            'strategic': [
                "This move fits well with the overall strategy of {strategy}.",
                "A strategic move that {strategy}, showing deep understanding of the position.",
                "This move reinforces the {strategy} plan that has been developing.",
                "With this move, {player} continues to pursue the {strategy} strategy."
            ],
            'pattern': [
                "This is a well-known pattern in this type of position.",
                "The move follows the classical approach to this type of formation.",
                "A standard move in this joseki sequence.",
                "This move is the modern approach, differing from older interpretations."
            ],
            'evaluation': [
                "{evaluation}. The position remains balanced but complex.",
                "{evaluation}, with both sides having chances.",
                "{evaluation}, but there are still many subtleties to navigate.",
                "The position is {adjective}, with {player} holding a slight advantage."
            ],
            'suggestion': [
                "An alternative worth considering would have been {alternative}.",
                "Another possibility here is {alternative}, though the played move is also good.",
                "The computer might prefer {alternative}, but the human move has its merits.",
                "While {alternative} is playable, the move chosen shows practical understanding."
            ]
        }
    
    def _load_style_guides(self) -> Dict[str, str]:
        """
        Load different commentary styles
        """
        return {
            'professional': "Provides objective analysis with professional terminology.",
            'educational': "Explains concepts clearly for learning purposes.",
            'enthusiastic': "Engaging commentary with excitement about interesting moves.",
            'technical': "Deep analysis focusing on technical aspects."
        }
    
    def generate_commentary(self, analysis: Dict[str, Any], move_number: int = None) -> str:
        """
        Generate natural language commentary based on analysis
        """
        # If Katago analysis is available, use the intent interpreter for professional-level commentary
        katago_analysis = analysis.get('katago_analysis')
        if katago_analysis:
            # Use the intent interpreter to generate professional commentary
            interpreted_analysis = self.intent_interpreter.interpret_katago_analysis(katago_analysis)
            return interpreted_analysis['commentary']
        
        # Fallback to basic commentary generation if no Katago analysis
        commentary_parts = []
        
        # Generate opening commentary if this is early in the game
        if move_number and move_number <= 30:
            opening_comment = self._generate_opening_commentary(analysis)
            if opening_comment:
                commentary_parts.append(opening_comment)
        
        # Generate move purpose commentary
        if analysis.get('move_analysis'):
            move_comment = self._generate_move_commentary(analysis['move_analysis'], move_number)
            commentary_parts.append(move_comment)
        
        # Generate position evaluation commentary
        pos_comment = self._generate_position_commentary(analysis['position_evaluation'])
        commentary_parts.append(pos_comment)
        
        # Add strategic element commentary if applicable
        if analysis.get('strategic_elements'):
            strat_comment = self._generate_strategic_commentary(analysis['strategic_elements'])
            if strat_comment:
                commentary_parts.append(strat_comment)
        
        # Add tactical situation commentary if applicable
        if analysis.get('tactical_situations') and analysis['tactical_situations']:
            tact_comment = self._generate_tactical_commentary(analysis['tactical_situations'])
            if tact_comment:
                commentary_parts.append(tact_comment)
        
        # Combine all parts into a coherent commentary
        final_commentary = " ".join(commentary_parts)
        
        # Add professional touches based on the type of position
        if analysis.get('strategic_elements', {}).get('strategic_theme') == 'middle_game_combination':
            final_commentary += f" The middle game complexities require deep reading and understanding of mutual damage principles."
        elif analysis.get('strategic_elements', {}).get('strategic_theme') == 'endgame_technique':
            final_commentary += f" Precise endgame technique will be crucial from this point forward."
        
        return final_commentary.strip()
    
    def _generate_opening_commentary(self, analysis: Dict[str, Any]) -> str:
        """
        Generate commentary specific to opening moves
        """
        if analysis.get('strategic_elements', {}).get('strategic_theme') != 'fuseki':
            return ""
        
        frameworks = analysis.get('strategic_elements', {}).get('frameworks', {})
        if not frameworks:
            return ""
        
        # Check if the position is more territory-oriented or influence-oriented
        black_territory = frameworks.get('black', {}).get('territory_oriented', 0)
        black_influence = frameworks.get('black', {}).get('influence_oriented', 0)
        white_territory = frameworks.get('white', {}).get('territory_oriented', 0)
        white_influence = frameworks.get('white', {}).get('influence_oriented', 0)
        
        if black_influence > black_territory and white_influence > white_territory:
            return "Both players are building influence rather than taking territory, leading to a complex middle game."
        elif black_territory > black_influence or white_territory > white_influence:
            return "The players are focusing on securing territory in the corners and sides, creating a more positional game."
        else:
            return "A balanced fuseki with both territorial and influential ideas being pursued."
    
    def _generate_move_commentary(self, move_analysis: Dict[str, Any], move_number: int = None) -> str:
        """
        Generate commentary about a specific move
        """
        commentary = ""
        
        # Start with the move's purpose
        purpose = move_analysis.get('move_purpose', 'address the position')
        template = random.choice(self.commentary_templates['move_purpose'])
        commentary = template.format(
            purpose=purpose,
            side=random.choice(['left', 'right', 'top', 'bottom', 'center'])
        )
        
        # Add tactical considerations if applicable
        if move_analysis.get('tactical_response') or move_analysis.get('tactical_creation'):
            tactical_part = self._generate_tactical_part(move_analysis)
            if tactical_part:
                commentary += " " + tactical_part
        
        # Add pattern recognition if applicable
        if move_analysis.get('pattern_match') and move_analysis['pattern_match'].get('matches'):
            pattern_part = self._generate_pattern_part(move_analysis)
            if pattern_part:
                commentary += " " + pattern_part
        
        # Add evaluation impact if significant
        eval_impact = move_analysis.get('eval_impact', 0)
        if abs(eval_impact) > 3:  # Significant change in evaluation
            sign = "Black" if eval_impact > 0 else "White"
            magnitude = "slightly" if abs(eval_impact) < 6 else "significantly"
            commentary += f" This move {magnitude} improves {sign}'s position."
        
        return commentary
    
    def _generate_tactical_part(self, move_analysis: Dict[str, Any]) -> str:
        """
        Generate commentary about tactical aspects of the move
        """
        if move_analysis.get('tactical_response'):
            # Move was a response to a threat
            return random.choice([
                "This move correctly deals with the immediate tactical threat.",
                "A precise response to the tactical situation that arose.",
                "The move handles the tactical problem efficiently."
            ])
        elif move_analysis.get('tactical_creation'):
            # Move created a tactical opportunity
            return random.choice([
                "This move creates tactical complications that favor Black/White.",
                "A move that introduces tactical elements into the position.",
                "The position becomes sharper after this tactical insertion."
            ])
        else:
            return ""
    
    def _generate_pattern_part(self, move_analysis: Dict[str, Any]) -> str:
        """
        Generate commentary about pattern recognition
        """
        matches = move_analysis.get('pattern_match', {}).get('matches', [])
        if not matches:
            return ""
        
        # Take the highest confidence match
        best_match = max(matches, key=lambda x: x.get('confidence', 0))
        
        if best_match['confidence'] > 0.7:
            return f"This follows the classical {best_match['name']} pattern, demonstrating good joseki knowledge."
        elif best_match['confidence'] > 0.5:
            return f"The move resembles the {best_match['name']} pattern, though played in a slightly different context."
        else:
            return "An unconventional move that departs from standard patterns, showing creative thinking."
    
    def _generate_position_commentary(self, position_eval: Dict[str, Any]) -> str:
        """
        Generate commentary about the overall position evaluation
        """
        # Determine the evaluation summary
        black_advantage = position_eval.get('black_advantage', 0)
        win_prob = position_eval.get('win_probability', 0.5)
        complexity = position_eval.get('complexity', 0.5)
        
        if abs(black_advantage) < 3:
            eval_text = "The position is very close with both sides having equal chances"
        elif black_advantage > 0:
            if black_advantage > 10:
                eval_text = "Black has a clear advantage in this position"
            else:
                eval_text = "Black holds a slight advantage"
        else:
            if black_advantage < -10:
                eval_text = "White has a clear advantage in this position"
            else:
                eval_text = "White holds a slight advantage"
        
        # Determine complexity descriptor
        if complexity > 0.7:
            complexity_desc = "complicated"
        elif complexity > 0.4:
            complexity_desc = "moderately complex"
        else:
            complexity_desc = "relatively simple"
        
        # Combine evaluation with complexity
        template = random.choice(self.commentary_templates['evaluation'])
        commentary = template.format(
            evaluation=eval_text,
            adjective=complexity_desc,
            player="Black" if black_advantage > 0 else "White"
        )
        
        return commentary
    
    def _generate_strategic_commentary(self, strategic_elements: Dict[str, Any]) -> str:
        """
        Generate commentary about strategic elements
        """
        # Check for moyos
        moyos = strategic_elements.get('moyos', [])
        if moyos:
            largest_moyo = max(moyos, key=lambda x: x.get('size', 0))
            if largest_moyo['size'] > 20:
                return f"{largest_moyo['dominant_color'].title()} has established a large moyo on the {self._describe_side(largest_moyo['center_of_mass'])}, which will be a major factor in the middle game."
        
        # Check for strategic theme
        theme = strategic_elements.get('strategic_theme', '')
        if theme == 'middle_game_combination':
            return "The position has entered a complex middle game phase where tactical and strategic elements are intertwined."
        elif theme == 'endgame_technique':
            return "We've reached the endgame where precise technique will determine the outcome."
        else:
            return "The position maintains strategic balance with both players having viable plans."
    
    def _generate_tactical_commentary(self, tactical_situations: List[Dict[str, Any]]) -> str:
        """
        Generate commentary about tactical situations
        """
        if not tactical_situations:
            return ""
        
        # Count different types of tactical situations
        atari_count = sum(1 for t in tactical_situations if t.get('type') == 'atari')
        capture_count = sum(1 for t in tactical_situations if t.get('type') == 'potential_capture')
        ladder_count = sum(1 for t in tactical_situations if t.get('type') == 'ladder')
        
        commentary_parts = []
        
        if atari_count > 0:
            commentary_parts.append(f"There are {atari_count} group{'s' if atari_count > 1 else ''} currently in atari, requiring immediate attention.")
        
        if capture_count > 0:
            potential_captures = sum(t.get('captured_count', 0) for t in tactical_situations if t.get('type') == 'potential_capture')
            if potential_captures > 0:
                commentary_parts.append(f"There are potential captures involving {potential_captures} stone{'s' if potential_captures > 1 else ''}.")
        
        if ladder_count > 0:
            commentary_parts.append(f"At least one ladder is forming, which could become a major tactical sequence.")
        
        return " ".join(commentary_parts)
    
    def _describe_side(self, center: Tuple[float, float]) -> str:
        """
        Describe which side of the board a center point is on
        """
        x, y = center
        if x < 6 and y < 6:
            return "upper left corner"
        elif x > 12 and y < 6:
            return "upper right corner"
        elif x < 6 and y > 12:
            return "lower left corner"
        elif x > 12 and y > 12:
            return "lower right corner"
        elif x < 6:
            return "left side"
        elif x > 12:
            return "right side"
        elif y < 6:
            return "top side"
        elif y > 12:
            return "bottom side"
        else:
            return "center"
    
    def generate_detailed_commentary(self, analysis: Dict[str, Any], move_number: int = None) -> Dict[str, str]:
        """
        Generate detailed commentary broken down by aspect
        """
        return {
            'summary': self.generate_commentary(analysis, move_number),
            'position_evaluation': self._generate_position_commentary(analysis['position_evaluation']),
            'strategic_elements': self._generate_strategic_commentary(analysis['strategic_elements']) if analysis.get('strategic_elements') else "",
            'tactical_situations': self._generate_tactical_commentary(analysis['tactical_situations']) if analysis.get('tactical_situations') else "",
            'move_significance': self._generate_move_commentary(analysis['move_analysis'], move_number) if analysis.get('move_analysis') else ""
        }


def example_usage():
    """
    Example of how to use the commentary generator
    """
    generator = CommentaryGenerator()
    
    # Sample analysis data
    sample_analysis = {
        'position_evaluation': {
            'black_advantage': 5.2,
            'win_probability': 0.68,
            'complexity': 0.75,
            'balance': 0.3
        },
        'strategic_elements': {
            'moyos': [{
                'area': [(3, 3), (3, 4), (4, 3)],
                'dominant_color': 'black',
                'size': 25,
                'center_of_mass': (3.5, 3.5)
            }],
            'strategic_theme': 'middle_game_combination'
        },
        'tactical_situations': [
            {
                'type': 'atari',
                'group': [(10, 10), (10, 11)],
                'urgency': 'high'
            }
        ],
        'move_analysis': {
            'eval_impact': 2.1,
            'move_purpose': 'strengthen the position on the upper side',
            'tactical_response': True,
            'strategic_alignment': 'moyo building',
            'pattern_match': {
                'matches': [
                    {
                        'name': 'sanrensei',
                        'confidence': 0.8,
                        'description': 'Three-star formation',
                        'professional_frequency': 0.6
                    }
                ]
            }
        }
    }
    
    commentary = generator.generate_commentary(sample_analysis, move_number=45)
    print("Generated Commentary:")
    print(commentary)
    
    detailed = generator.generate_detailed_commentary(sample_analysis, move_number=45)
    print("\nDetailed Breakdown:")
    for key, value in detailed.items():
        print(f"{key.replace('_', ' ').title()}: {value}")
    
    return commentary


if __name__ == "__main__":
    example_usage()