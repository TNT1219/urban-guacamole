#!/usr/bin/env python3
"""
Test script to verify the Go Commentary Engine is working properly
"""

from go_commentary_engine import GoCommentarySystem, GoBoard, Stone
import numpy as np


def test_basic_functionality():
    """Test basic functionality of the Go Commentary Engine"""
    print("Testing Go Commentary Engine...")
    
    # Create a system instance
    system = GoCommentarySystem()
    print("✓ System initialized")
    
    # Test board creation
    board = GoBoard()
    print("✓ Board created")
    
    # Test a simple position
    print("\nTesting simple position analysis...")
    analysis = system.analyze_single_position(board, Stone.BLACK)
    print(f"✓ Position evaluated: {analysis['analysis']['position_evaluation']}")
    
    # Print sample commentary
    print(f"\nSample commentary: {analysis['commentary'][:200]}...")
    

def test_sgf_parsing():
    """Test SGF parsing functionality"""
    print("\nTesting SGF parsing...")
    
    from go_commentary_engine import SGFParser
    
    # Sample SGF content
    sample_sgf = "(;FF[4]GM[1]SZ[19]PB[Murakawa Daisuke]PW[Iyama Yuta]KM[6.5]HA[0]RE[W+1.5];B[qd];W[dd];B[pq];W[dq];B[fc])"
    
    parser = SGFParser()
    game_data = parser.parse(sample_sgf)
    
    print(f"✓ Properties parsed: {len(game_data['properties'])} properties")
    print(f"✓ Moves parsed: {len(game_data['moves'])} moves")


def test_analysis_engine():
    """Test analysis engine functionality"""
    print("\nTesting analysis engine...")
    
    from go_commentary_engine import AnalysisEngine, GoBoard
    
    engine = AnalysisEngine()
    board = GoBoard()
    
    # Perform position analysis
    analysis = engine.analyze_position(board)
    
    print(f"✓ Position evaluation: {analysis['position_evaluation']}")
    print(f"✓ Strategic elements: {analysis['strategic_elements']['strategic_theme']}")


def test_commentary_generation():
    """Test commentary generation"""
    print("\nTesting commentary generation...")
    
    from go_commentary_engine import CommentaryGenerator
    
    generator = CommentaryGenerator()
    
    # Sample analysis data
    sample_analysis = {
        'position_evaluation': {
            'black_advantage': 2.5,
            'win_probability': 0.58,
            'complexity': 0.45,
            'balance': 0.7
        },
        'strategic_elements': {
            'moyos': [],
            'strategic_theme': 'fuseki'
        },
        'tactical_situations': [],
        'move_analysis': {
            'eval_impact': 1.2,
            'move_purpose': 'secure the corner',
            'tactical_response': False,
            'strategic_alignment': 'territorial development',
            'pattern_match': {
                'matches': []
            }
        }
    }
    
    commentary = generator.generate_commentary(sample_analysis, move_number=10)
    print(f"✓ Generated commentary: {commentary[:150]}...")


if __name__ == "__main__":
    print("Go Commentary Engine - Functionality Test")
    print("=" * 50)
    
    test_basic_functionality()
    test_sgf_parsing()
    test_analysis_engine()
    test_commentary_generation()
    
    print("\n" + "=" * 50)
    print("All tests passed! Go Commentary Engine is working properly.")