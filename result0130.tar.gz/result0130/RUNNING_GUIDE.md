# TW1.0.0 运行指南

## 系统要求
- Python 3.8+
- 至少4GB内存
- 支持CUDA的GPU（推荐，用于Katago引擎）

## 安装步骤

### 1. 克隆项目
```bash
git clone <repository-url>
cd <project-directory>
```

### 2. 创建虚拟环境
```bash
python -m venv venv
source venv/bin/activate  # Linux/Mac
# 或
venv\Scripts\activate  # Windows
```

### 3. 安装依赖
```bash
pip install -r requirements.txt
```

### 4. 配置Katago（可选但推荐）
1. 下载Katago引擎：https://github.com/lightvector/KataGo/releases
2. 下载神经网络模型文件
3. 更新配置文件中的Katago路径

## 运行方法

### 方法一：使用示例脚本
```bash
python demo_professional_level.py
```

### 方法二：直接运行主程序
```bash
python final_demo.py
```

### 方法三：API模式运行
```bash
python -m go_commentary_engine.main
```

## 使用说明

1. 准备SGF格式的围棋棋谱文件
2. 运行程序并加载棋谱
3. 系统将自动分析棋局并生成专业级解说
4. 查看分析结果和建议

## 主要功能

- SGF棋谱解析
- 专业级棋局分析
- 意图识别与错误分析
- 实时胜率变化曲线
- 推荐走法建议

## 注意事项

- 确保有足够的内存资源运行Katago引擎
- 首次运行可能需要较长的初始化时间
- 大型棋谱文件分析可能需要几分钟时间