#!/usr/bin/env python3
"""
SGF文件问题手分析工具
通过AI评估数据找出最大的问题手
"""

import re

def parse_sgf_with_ai_analysis(file_path):
    """解析SGF文件和AI分析数据"""
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # 提取棋步
    moves = []
    move_pattern = r'(B|W)\[([a-z]{2}|--)\]'
    matches = re.findall(move_pattern, content)
    
    for i, (color, coord) in enumerate(matches):
        if coord != '--':  # 不是虚手
            # 计算坐标（SGF使用小写字母表示坐标）
            x = ord(coord[0]) - ord('a')  # 列
            y = ord(coord[1]) - ord('a')  # 行
            moves.append({
                'move_number': i + 1,
                'color': color,
                'coordinate': coord,
                'x': x,
                'y': y,
                'algebraic': f"{chr(ord('A') + x)}{19 - y}"
            })
    
    # 提取AI评估数据
    ai_data = []
    ai_pattern = r'AQ\[([^\]]*)\]'
    ai_matches = re.findall(ai_pattern, content)
    
    for i, ai_text in enumerate(ai_matches):
        # 解析AI数据，寻找utility值
        utility_match = re.search(r'utilit[y]?\s+(-?\d+\.?\d*)', ai_text)
        winrate_match = re.search(r'winrate\s+(\d+\.?\d*)', ai_text)
        
        if utility_match:
            utility = float(utility_match.group(1))
            winrate = float(winrate_match.group(1)) if winrate_match else None
            ai_data.append({
                'move_number': i + 1,
                'utility': utility,
                'winrate': winrate,
                'ai_text': ai_text
            })
    
    return moves, ai_data

def find_biggest_mistake(ai_data, moves):
    """找出最大的问题手"""
    if not ai_data:
        return None
    
    # 找出utility变化最大的点（负值表示损失）
    biggest_drops = []
    
    for i in range(1, len(ai_data)):
        prev_utility = ai_data[i-1]['utility']
        curr_utility = ai_data[i]['utility']
        
        # 计算效用下降（负值表示损失）
        utility_drop = prev_utility - curr_utility
        
        if utility_drop > 0.1:  # 只考虑明显的失误
            # 查找对应的棋步编号
            move_num = ai_data[i]['move_number']
            
            # 找到对应的棋步信息
            move_info = None
            for move in moves:
                if move['move_number'] == move_num:
                    move_info = move
                    break
            
            biggest_drops.append({
                'move_number': move_num,
                'utility_drop': utility_drop,
                'prev_utility': prev_utility,
                'curr_utility': curr_utility,
                'move_info': move_info
            })
    
    if biggest_drops:
        # 按效用下降排序
        biggest_drops.sort(key=lambda x: x['utility_drop'], reverse=True)
        return biggest_drops[0]
    
    return None

def analyze_specific_mistakes(ai_data, moves):
    """分析特定的严重失误"""
    severe_mistakes = []
    
    for i, data in enumerate(ai_data):
        utility = data['utility']
        
        # 查找极端负效用（严重失误）
        if utility < -0.5:  # 严重劣势
            move_num = data['move_number']
            
            # 找到对应的棋步信息
            move_info = None
            for move in moves:
                if move['move_number'] == move_num:
                    move_info = move
                    break
            
            severe_mistakes.append({
                'move_number': move_num,
                'utility': utility,
                'move_info': move_info
            })
    
    # 按效用值排序（最负的在前）
    severe_mistakes.sort(key=lambda x: x['utility'])
    return severe_mistakes

# 使用您上传的SGF文件路径
sgf_file_path = '/root/.clawdbot/media/inbound/2025-12-30_251230_223227---8d04c9c7-af5f-4e7d-803f-183da00716c3'

print("SGF文件问题手分析")
print("="*60)

try:
    moves, ai_data = parse_sgf_with_ai_analysis(sgf_file_path)
    
    print(f"✓ 解析成功")
    print(f"✓ 总棋步数: {len(moves)}")
    print(f"✓ AI分析数据: {len(ai_data)} 条")
    
    # 分析严重的负效用手（直接导致局势恶化的手）
    severe_mistakes = analyze_specific_mistakes(ai_data, moves)
    
    print(f"\n严重问题手分析:")
    print("-" * 40)
    
    if severe_mistakes:
        # 显示最严重的几个问题手
        for i, mistake in enumerate(severe_mistakes[:5]):
            move_info = mistake['move_info']
            color = "黑棋" if move_info['color'] == 'B' else "白棋" if move_info else "?"
            coord = move_info['algebraic'] if move_info else "?"
            
            print(f"{i+1}. 第{mistake['move_number']:2d}手 {color} {coord} "
                  f"(效用: {mistake['utility']:.3f})")
    else:
        print("未发现明显的严重问题手")
    
    # 分析效用下降最大的连续手
    biggest_mistake = find_biggest_mistake(ai_data, moves)
    
    print(f"\n效用下降最大的连续手:")
    print("-" * 40)
    
    if biggest_mistake:
        move_info = biggest_mistake['move_info']
        color = "黑棋" if move_info['color'] == 'B' else "白棋" if move_info else "?"
        coord = move_info['algebraic'] if move_info else "?"
        
        print(f"第{biggest_mistake['move_number']:2d}手 {color} {coord}")
        print(f"效用下降: {biggest_mistake['utility_drop']:.3f}")
        print(f"前一手效用: {biggest_mistake['prev_utility']:.3f}")
        print(f"后一手效用: {biggest_mistake['curr_utility']:.3f}")
    else:
        print("未发现明显的效用大幅下降")
    
    # 综合分析
    print(f"\n综合分析:")
    print("-" * 40)
    
    if severe_mistakes:
        worst_mistake = severe_mistakes[0]  # 最严重的问题手
        move_info = worst_mistake['move_info']
        color = "黑棋" if move_info['color'] == 'B' else "白棋" if move_info else "?"
        coord = move_info['algebraic'] if move_info else "?"
        
        print(f"最大问题手: 第{worst_mistake['move_number']:2d}手 {color} {coord}")
        print(f"原因: 此手导致局势急剧恶化，效用降至 {worst_mistake['utility']:.3f}")
        print(f"这手棋明显偏离了AI推荐的最佳着法，造成了重大的战略损失")
    else:
        print("整个对局中未发现特别突出的严重失误，双方都保持了相对稳定的着法")

except Exception as e:
    print(f"分析过程中出现错误: {str(e)}")
    import traceback
    traceback.print_exc()

print("\n" + "="*60)
print("分析完成")