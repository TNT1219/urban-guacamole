"""
Move Intent Interpreter - Interprets Katago analysis and generates professional commentary
This is the core of the professional-level commentary system
"""
from typing import Dict, List, Any, Tuple
from .katago_interface import KatagoAnalysisProcessor
import re


class MoveIntentInterpreter:
    """
    Interprets Katago analysis data and translates it into professional-level commentary
    This is the key component that differentiates our system
    """
    
    def __init__(self):
        self.processor = KatagoAnalysisProcessor()
        self.go_terms = self._load_go_terms()
        self.commentary_templates = self._load_commentary_templates()
        
    def _load_go_terms(self) -> Dict[str, List[str]]:
        """
        Load professional Go terminology organized by concept
        """
        return {
            'fuseki': [
                'opening', 'enclosure', 'approach', 'invade', 'extend', 
                'shoulder hit', 'high approach', 'low approach', 'framework',
                'sanrensei', 'nirensei', 'kobayashi joseki', 'shimari',
                'kogeima', 'keima', 'ikken tobi', 'niken tobi', 'hoshi',
                'komoku', 'mokuhazushi', 'takamoku', 'sansan'
            ],
            'middle_game': [
                'fighting', 'attacking', 'defending', 'cutting', 'connecting',
                'life and death', 'semeai', 'aji', 'thickness', 'lightness',
                'sacrifice', 'compensation', 'escalation', 'squeezing',
                'switching', 'timing', 'aji-keshi', 'heavy', 'light',
                'over-concentration', 'shape', 'efficiency', 'initiative',
                'profit', 'direction', 'reduction', 'weakening'
            ],
            'endgame': [
                'yose', 'gote', 'sente', 'reverse sente', 'miai', 'tsuke',
                'boundary', 'mutual damage', 'ko fight', 'temple escape',
                'gote move', 'sente move', 'reverse sente', 'endgame tesuji',
                'sentest', 'gotes', 'miai values', 'deiri counting',
                'territorial counting', 'ko threats', 'critical endgame'
            ],
            'shape': [
                'good shape', 'bad shape', 'empty triangle', 'bamboo joint',
                'one point jump', 'two point jump', 'diagonal', 'dogzuki',
                'bulky five', 'crosscut', 'hane', 'ikken tobi', 'hasami',
                'nobis', 'eye-stealing', 'throwing-in', 'net', 'connect',
                'disconnect', 'stretching', 'leaning', 'turning', 'pushing',
                'peeping', 'bamboo joint', 'table', 'mouth-shape', 'crosscut',
                'cap', 'hane', 'descent', 'shoulder hit', 'squeeze'
            ],
            'evaluation': [
                'Black is ahead', 'White is ahead', 'Even position', 
                'Complicated position', 'Sharp position', 'Quiet position',
                'Advantage', 'Mistake', 'Blunder', 'Inaccuracy',
                'Winning position', 'Drawing position', 'Losing position',
                'Unclear position', 'Balanced position', 'Critical position',
                'Decisive advantage', 'Slight advantage', 'Complex battle'
            ],
            'professional_commentary': [
                'proverb', 'common pattern', 'classical', 'modern approach',
                'deep learning influenced', 'traditional', 'creative',
                'standard', 'innovative', 'classical joseki', 'modern joseki',
                'flexible', 'aggressive', 'defensive', 'balanced',
                'sharp fighting', 'quiet moves', 'prophylactic',
                'positional understanding', 'intuitive', 'calculated',
                'sacrificial', 'territorial', 'influential', 'central'
            ]
        }
    
    def _load_commentary_templates(self) -> Dict[str, List[str]]:
        """
        Load templates for different types of commentary
        """
        return {
            'positive_move': [
                "Excellent move! {player} demonstrates profound positional understanding by {purpose}, which aligns with the classical principle of {principle}.",
                "A move of great depth! {player} addresses the position's demands with {purpose}, showing {characteristic} judgment.",
                "Very instructive! This move {purpose}, exhibiting the kind of positional sensitivity that distinguishes professionals.",
                "Outstanding positional judgment! {player} {purpose}, perfectly embodying the concept of {concept}.",
                "A masterful touch! The subtle strength of {purpose} reveals {player}'s superior understanding of {aspect}."
            ],
            'negative_move': [
                "{player} has missed the critical moment. By {problem}, they have allowed {opponent} to gain the upper hand through {advantage}.",
                "This move lacks urgency in such a critical position. {player} should have focused on {priority} instead of {current_action}.",
                "A significant misjudgment! The position demanded {correct_approach}, but {player} chose {incorrect_approach}, leading to {consequence}.",
                "This move reveals a misunderstanding of the position's dynamics. {player} failed to appreciate the importance of {factor}.",
                "A grave error in a balanced position! {player}'s move {problem} fundamentally misjudges the {aspect} of the position."
            ],
            'missed_opportunity': [
                "The truly critical move here was {alternative}, which would have {benefit}. This exemplifies the principle of {principle}.",
                "{player} missed a brilliant opportunity with {alternative}, which would have created {advantage} through {method}.",
                "As seen in professional games, {alternative} would have been the correct approach, leading to {benefit} for {player}.",
                "The classical approach of {alternative} would have yielded {benefit}, demonstrating {principle} in action.",
                "Simply {alternative} would have sufficed, showcasing the importance of {concept} in such positions."
            ],
            'strategic_assessment': [
                "This is a position that demands {characteristic} judgment. Both players have demonstrated {aspect}, but {player} has achieved {advantage}.",
                "A typical {type} position where {principle} becomes paramount. {player} seems better prepared for the resulting complications.",
                "The position has evolved into a classic {structure}, where {factor} will prove decisive. {player} appears more comfortable with this type of position.",
                "From a professional's perspective, this position highlights the importance of {concept}. {player} has handled the opening phase in accordance with classical teachings.",
                "A complex middlegame position with both sides having chances. The player who better understands {aspect} will likely emerge victorious."
            ],
            'tactical_explanation': [
                "The tactical foundation of this move lies in the fact that if {opponent} attempts {countermove}, then {sequence} leads to {result}.",
                "This move contains a hidden trap: if {opponent} responds with {response}, {player} can spring the tesuji {tesuji}, resulting in {advantage}.",
                "The key tactical point is that {opponent} cannot afford to ignore this threat, as doing so would lead to {consequence}.",
                "The tactical justification for this move is that it prevents {opponent} from playing {dangerous_move}, which would have created serious problems.",
                "Careful reading reveals that this sequence is forced for {opponent}, as any deviation would result in {negative_outcome}."
            ],
            'pattern_explanation': [
                "This is the classical approach to this type of position, as demonstrated in numerous professional games. The resulting shape is {characteristic}.",
                "A modern innovation that deviates from traditional theory. While {alternative} has been favored historically, this approach offers {advantage}.",
                "Following the standard joseki, which results in a balanced position with both sides satisfied with their development.",
                "A creative deviation from standard patterns, attempting to {goal} while avoiding {drawback} of the classical approach.",
                "This rare but valuable variation is occasionally employed by top professionals when seeking {advantage}."
            ],
            'professional_insight': [
                "This position beautifully illustrates the principle of {principle}, which is fundamental to professional-level understanding.",
                "A position that separates amateurs from professionals. The key concept here is {concept}, which {player} has grasped intuitively.",
                "From the perspective of {school_or_player}, this is the proper approach, emphasizing {aspect} over immediate territorial gains.",
                "This move exemplifies the concept of {idea}, a cornerstone of professional Go theory.",
                "An elegant solution that harmonizes the principles of {factor1} and {factor2}, characteristic of high-level play."
            ]
        }
    
    def interpret_katago_analysis(self, katago_analysis: Dict[str, Any], 
                                 previous_analysis: Dict[str, Any] = None) -> Dict[str, Any]:
        """
        Interpret Katago's analysis and extract professional-level insights
        """
        if not katago_analysis:
            return {
                'commentary': "No Katago analysis available for this position.",
                'move_quality': 'unknown',
                'strategic_insights': [],
                'tactical_notes': [],
                'suggestions': []
            }
        
        insights = {
            'move_quality': self._assess_move_quality(katago_analysis, previous_analysis),
            'strategic_insights': self._extract_strategic_insights(katago_analysis),
            'tactical_notes': self._extract_tactical_notes(katago_analysis),
            'suggestions': self._generate_suggestions(katago_analysis),
            'commentary': self._generate_professional_commentary(katago_analysis, previous_analysis)
        }
        
        return insights
    
    def _assess_move_quality(self, current_analysis: Dict[str, Any], 
                           previous_analysis: Dict[str, Any] = None) -> str:
        """
        Assess the quality of the last move based on win rate changes
        """
        if not previous_analysis or not current_analysis:
            return "unknown"
        
        # This would normally look at winrate changes
        # For now, we'll return a placeholder
        return "good"  # Placeholder - would analyze winrate change in real implementation
    
    def _extract_strategic_insights(self, analysis: Dict[str, Any]) -> List[str]:
        """
        Extract strategic insights from the analysis
        """
        insights = []
        
        # Look for strategic elements in the analysis
        if analysis.get('moves'):
            top_move = analysis['moves'][0] if analysis['moves'] else None
            if top_move:
                # Analyze the characteristics of the best move
                if 'pv' in top_move and len(top_move['pv']) > 3:
                    insights.append("The position requires deep reading to fully understand.")
                
                if top_move.get('visits', 0) > 5000:
                    insights.append("Katago has high confidence in this position.")
        
        # Add general strategic observations
        if analysis.get('position_eval', {}).get('centipawn', 0) > 50:
            insights.append("Black has a clear advantage based on territory and influence.")
        elif analysis.get('position_eval', {}).get('centipawn', 0) < -50:
            insights.append("White has a clear advantage based on territory and influence.")
        else:
            insights.append("The position is relatively balanced.")
        
        return insights
    
    def _extract_tactical_notes(self, analysis: Dict[str, Any]) -> List[str]:
        """
        Extract tactical observations from the analysis
        """
        notes = []
        
        # Look for tactical elements in the analysis
        if analysis.get('moves'):
            # Examine top few moves for tactical differences
            top_moves = analysis['moves'][:3]
            
            if len(top_moves) > 1:
                best_winrate = top_moves[0].get('winrate', 0)
                second_best = top_moves[1].get('winrate', 0)
                
                if best_winrate - second_best > 10:  # Significant difference
                    notes.append(f"The best move has a clear advantage over alternatives.")
        
        return notes
    
    def _generate_suggestions(self, analysis: Dict[str, Any]) -> List[str]:
        """
        Generate suggestions based on the analysis
        """
        suggestions = []
        
        if analysis.get('moves'):
            top_moves = analysis['moves'][:3]
            if len(top_moves) > 1:
                # Suggest the second best move as an alternative
                second_best = top_moves[1]
                if 'move' in second_best:
                    suggestions.append(f"As an alternative, consider {second_best['move']}")
        
        return suggestions
    
    def _generate_professional_commentary(self, 
                                       current_analysis: Dict[str, Any], 
                                       previous_analysis: Dict[str, Any] = None) -> str:
        """
        Generate professional-level commentary based on the analysis
        """
        commentary_parts = []
        
        # Start with position assessment
        position_assessment = self._assess_position(current_analysis)
        commentary_parts.append(position_assessment)
        
        # Add strategic element
        if current_analysis.get('moves'):
            strategic_element = self._describe_strategic_element(current_analysis['moves'][0])
            commentary_parts.append(strategic_element)
        
        # Add tactical element if applicable
        if current_analysis.get('moves'):
            tactical_element = self._describe_tactical_element(current_analysis['moves'][0])
            if tactical_element:
                commentary_parts.append(tactical_element)
        
        # Add overall assessment
        overall_assessment = self._overall_position_assessment(current_analysis)
        commentary_parts.append(overall_assessment)
        
        return " ".join(commentary_parts)
    
    def _assess_position(self, analysis: Dict[str, Any]) -> str:
        """
        Assess the current position
        """
        centipawn = analysis.get('position_eval', {}).get('centipawn', 0)
        winrate = analysis.get('position_eval', {}).get('winrate', 50.0)
        
        if abs(centipawn) < 30:
            return "The position remains evenly balanced with both sides having reasonable prospects."
        elif centipawn > 0:
            return f"Black has gained a slight advantage of approximately {centipawn/100:.1f} points."
        else:
            return f"White has gained a slight advantage of approximately {abs(centipawn)/100:.1f} points."
    
    def _describe_strategic_element(self, top_move: Dict[str, Any]) -> str:
        """
        Describe the strategic element of the best move
        """
        if not top_move:
            return "The position requires careful consideration of strategic priorities."
        
        # Determine what the move accomplishes strategically
        if 'pv' in top_move and len(top_move['pv']) > 2:
            return "The position demands deep strategic understanding, with the best continuation involving multiple forcing moves."
        else:
            return "The position requires balancing territorial and strategic considerations."
    
    def _describe_tactical_element(self, top_move: Dict[str, Any]) -> str:
        """
        Describe any tactical elements
        """
        if not top_move:
            return ""
        
        visits = top_move.get('visits', 0)
        if visits > 8000:
            return "Katago has thoroughly examined this position and confirms the soundness of the continuation."
        elif visits < 2000:
            return "The position contains subtle tactical elements that require careful reading."
        else:
            return ""
    
    def _overall_position_assessment(self, analysis: Dict[str, Any]) -> str:
        """
        Provide an overall assessment of the position
        """
        moves = analysis.get('moves', [])
        if not moves:
            return "Further analysis would be needed to determine the best plan for both sides."
        
        # Look at the top move's characteristics
        top_move = moves[0]
        winrate = top_move.get('winrate', 50.0)
        
        if winrate > 60:
            return "Black stands better in this complex position."
        elif winrate < 40:
            return "White stands better in this complex position."
        else:
            return "The position remains unclear with chances for both sides."
    
    def generate_move_commentary(self, 
                               move_coords: Tuple[int, int], 
                               katago_analysis: Dict[str, Any],
                               board_state_description: str = "") -> str:
        """
        Generate specific commentary for a particular move
        """
        # Create commentary for a specific move
        if katago_analysis and katago_analysis.get('moves'):
            top_move = katago_analysis['moves'][0] if katago_analysis['moves'] else None
            if top_move:
                # Generate move-specific commentary
                move_notation = self._coords_to_gtp(move_coords)
                
                if top_move.get('move') == move_notation:
                    # The played move matches Katago's top recommendation
                    return f"The move {move_notation} is consistent with professional play, addressing the position's requirements effectively."
                else:
                    # The played move differs from Katago's recommendation
                    expected_move = top_move.get('move', 'the best move')
                    return f"Although {move_notation} is a reasonable move, {expected_move} was considered slightly superior in this position."
        
        # Fallback commentary
        return f"The move {move_coords[0]},{move_coords[1]} contributes to the overall position in a meaningful way."
    
    def _coords_to_gtp(self, coords: Tuple[int, int]) -> str:
        """
        Convert coordinates to GTP notation
        """
        x, y = coords
        if x < 0 or y < 0:
            return "pass"
        
        # Convert to GTP format (letters)
        letters = "ABCDEFGHJKLMNOPQRSTUVWXYZ"  # Note: skipping 'I'
        col = letters[y] if y < 8 else letters[y + 1]  # Adjust for missing 'I'
        row = letters[x] if x < 8 else letters[x + 1]  # Adjust for missing 'I'
        
        return f"{col}{row}"


# Example usage
if __name__ == "__main__":
    interpreter = MoveIntentInterpreter()
    print("Move Intent Interpreter initialized successfully!")
    print("This module interprets Katago analysis and generates professional commentary.")