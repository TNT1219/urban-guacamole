# Go Commentary Engine - Main Package Setup

# Import main classes for easy access
from .main import GoCommentarySystem
from .board import GoBoard, Stone
from .sgf_parser import SGFParser
from .analysis_engine import AnalysisEngine
from .commentary_generator import CommentaryGenerator
from .katago_interface import KatagoInterface, KatagoAnalysisProcessor
from .move_intent_interpreter import MoveIntentInterpreter
from .professional_enhancer import ProfessionalCommentaryEnhancer

__version__ = "TW1.0.0"
__author__ = "Clawdbot"
__description__ = "A professional-level Go/Baduk game analysis and commentary system"