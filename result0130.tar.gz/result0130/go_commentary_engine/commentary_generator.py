"""
Commentary Generator for the Go Commentary System
Transforms analysis data into natural language commentary
resembling professional Go commentary
"""
from typing import Dict, List, Any, Tuple
import random
from .move_intent_interpreter import MoveIntentInterpreter
from .professional_enhancer import ProfessionalCommentaryEnhancer


class CommentaryGenerator:
    def __init__(self):
        # Professional Go terminology and phrases
        self.terms = self._load_go_terms()
        self.commentary_templates = self._load_commentary_templates()
        self.style_guides = self._load_style_guides()
        self.intent_interpreter = MoveIntentInterpreter()
        self.professional_enhancer = ProfessionalCommentaryEnhancer()
    
    def _load_go_terms(self) -> Dict[str, List[str]]:
        """
        Load professional Go terminology organized by concept
        """
        return {
            'opening': [
                'fuseki', 'enclosure', 'approach', 'invade', 'extend', 
                'shoulder hit', 'high approach', 'low approach', 'framework',
                'sanrensei', 'nirensei', 'kobayashi joseki', 'shimari',
                'kogeima', 'keima', 'ikken tobi', 'niken tobi', 'hoshi',
                'komoku', 'mokuhazushi', 'takamoku', 'sansan'
            ],
            'middle_game': [
                'fighting', 'attacking', 'defending', 'cutting', 'connecting',
                'life and death', 'semeai', 'aji', 'thickness', 'lightness',
                'sacrifice', 'compensation', 'escalation', 'squeezing',
                'switching', 'timing', 'aji-keshi', 'heavy', 'light',
                'over-concentration', 'shape', 'efficiency', 'initiative',
                'profit', 'direction', 'reduction', 'weakening'
            ],
            'endgame': [
                'yose', 'gote', 'sente', 'reverse sente', 'miai', 'tsuke',
                'boundary', 'mutual damage', 'ko fight', 'temple escape',
                'gote move', 'sente move', 'reverse sente', 'endgame tesuji',
                'sentest', 'gotes', 'miai values', 'deiri counting',
                'territorial counting', 'ko threats', 'critical endgame'
            ],
            'shape': [
                'good shape', 'bad shape', 'empty triangle', 'bamboo joint',
                'one point jump', 'two point jump', 'diagonal', 'dogzuki',
                'bulky five', 'crosscut', 'hane', 'ikken tobi', 'hasami',
                'nobis', 'eye-stealing', 'throwing-in', 'net', 'connect',
                'disconnect', 'stretching', 'leaning', 'turning', 'pushing',
                'peeping', 'bamboo joint', 'table', 'mouth-shape', 'crosscut',
                'cap', 'hane', 'descent', 'shoulder hit', 'squeeze'
            ],
            'evaluation': [
                'Black is ahead', 'White is ahead', 'Even position', 
                'Complicated position', 'Sharp position', 'Quiet position',
                'Advantage', 'Mistake', 'Blunder', 'Inaccuracy',
                'Winning position', 'Drawing position', 'Losing position',
                'Unclear position', 'Balanced position', 'Critical position',
                'Decisive advantage', 'Slight advantage', 'Complex battle'
            ],
            'professional_commentary': [
                'proverb', 'common pattern', 'classical', 'modern approach',
                'deep learning influenced', 'traditional', 'creative',
                'standard', 'innovative', 'classical joseki', 'modern joseki',
                'flexible', 'aggressive', 'defensive', 'balanced',
                'sharp fighting', 'quiet moves', 'prophylactic',
                'positional understanding', 'intuitive', 'calculated',
                'sacrificial', 'territorial', 'influential', 'central'
            ]
        }
    
    def _load_commentary_templates(self) -> Dict[str, List[str]]:
        """
        Load commentary templates for different types of analysis
        """
        return {
            'move_purpose': [
                "This move exemplifies the principle of {principle}, demonstrating {player}'s deep understanding of positional concepts.",
                "{player} exhibits masterful technique with {move}, addressing the position's demands through {method}.",
                "A move of great subtlety! {player} {purpose}, showing profound comprehension of {aspect}.",
                "This move reflects {player}'s ability to prioritize correctly in complex positions, focusing on {priority}.",
                "With {move}, {player} demonstrates classical wisdom by {principle}, which proves highly effective here."
            ],
            'tactical': [
                "The tactical foundation of this move is that if {opponent} attempts {countermove}, {player} can respond with {response}, leading to {advantage}.",
                "{player} executes a beautiful combination, forcing {opponent} into a position where any response leads to {outcome}.",
                "This move contains a subtle threat that {opponent} may not have fully appreciated, creating {advantage} for {player}.",
                "Careful reading reveals that {player}'s move is tactically sound, as {opponent} cannot afford to {response} due to {tactical_sequence}.",
                "The position now contains a forcing sequence that {player} has calculated precisely, leading to {advantage}."
            ],
            'strategic': [
                "This move embodies the strategic concept of {concept}, which {player} has applied with perfect timing.",
                "A strategic masterpiece! {player} {strategy}, demonstrating a deep understanding of {aspect}.",
                "With this move, {player} begins implementing a long-term strategy based on {principle}, which will prove effective in the coming stages.",
                "This move shows {player}'s ability to switch between tactical and strategic thinking, as it simultaneously {tactical_element} and {strategic_element}.",
                "{player} demonstrates positional mastery by {strategy}, perfectly adapting to the position's requirements."
            ],
            'pattern': [
                "This follows the classical joseki, which has been tested by countless professional games. The resulting position is {evaluation}.",
                "A modern innovation that departs from traditional theory, offering {advantage} while avoiding {drawback} of the classical approach.",
                "This rare but valuable variation is occasionally employed by top professionals when seeking {advantage}.",
                "The move represents a fusion of classical principles with modern understanding, showing {player}'s versatility.",
                "By choosing this pattern, {player} indicates a preference for {style} positions, which suits their overall strategy."
            ],
            'evaluation': [
                "{evaluation}. From a professional's perspective, {player} has achieved the ideal result from the opening phase.",
                "{evaluation}, but the position remains rich with possibilities. The player who better understands {aspect} will gain the upper hand.",
                "{evaluation}, with both sides having achieved their strategic objectives. The game now transitions to the {phase} stage.",
                "The position is dynamically balanced, with chances for both sides. The upcoming moves will prove critical to the game's outcome.",
                "{evaluation}, but {player} has demonstrated superior positional understanding throughout this complex sequence."
            ],
            'suggestion': [
                "As an alternative, {alternative} would have been consistent with the classical approach, leading to {different_outcome}.",
                "Professional players might consider {alternative}, which emphasizes {aspect} over the immediate territorial concerns addressed by the played move.",
                "The computer may prefer {alternative}, but {player}'s choice reflects human understanding of {concept}, which is often more valuable in complex positions.",
                "While {alternative} maintains theoretical equality, {player}'s move creates more practical difficulties for {opponent}.",
                "In tournament practice, {alternative} is often preferred as it leads to clearer positions, but {player}'s choice shows creativity."
            ],
            'professional_insight': [
                "This position beautifully illustrates the classical principle of {principle}, which is fundamental to professional-level understanding.",
                "A position that separates strong amateur players from professionals. The key concept here is {concept}, which {player} has grasped intuitively.",
                "From the perspective of {famous_player_or_school}, this is the proper approach, emphasizing {aspect} over immediate territorial gains.",
                "This move exemplifies the concept of {idea}, a cornerstone of professional Go theory that many amateurs struggle to comprehend.",
                "An elegant solution that harmonizes the principles of {factor1} and {factor2}, characteristic of high-level play."
            ]
        }
    
    def _load_style_guides(self) -> Dict[str, str]:
        """
        Load different commentary styles
        """
        return {
            'professional': "Provides objective analysis with professional terminology.",
            'educational': "Explains concepts clearly for learning purposes.",
            'enthusiastic': "Engaging commentary with excitement about interesting moves.",
            'technical': "Deep analysis focusing on technical aspects."
        }
    
    def generate_commentary(self, analysis: Dict[str, Any], move_number: int = None) -> str:
        """
        Generate natural language commentary based on analysis
        """
        # If Katago analysis is available, use the intent interpreter for professional-level commentary
        katago_analysis = analysis.get('katago_analysis')
        if katago_analysis:
            # Use the intent interpreter to generate professional commentary
            interpreted_analysis = self.intent_interpreter.interpret_katago_analysis(katago_analysis)
            basic_commentary = interpreted_analysis['commentary']
        else:
            # Fallback to basic commentary generation if no Katago analysis
            commentary_parts = []
            
            # Generate opening commentary if this is early in the game
            if move_number and move_number <= 30:
                opening_comment = self._generate_opening_commentary(analysis)
                if opening_comment:
                    commentary_parts.append(opening_comment)
            
            # Generate move purpose commentary
            if analysis.get('move_analysis'):
                move_comment = self._generate_move_commentary(analysis['move_analysis'], move_number)
                commentary_parts.append(move_comment)
            
            # Generate position evaluation commentary
            pos_comment = self._generate_position_commentary(analysis['position_evaluation'])
            commentary_parts.append(pos_comment)
            
            # Add strategic element commentary if applicable
            if analysis.get('strategic_elements'):
                strat_comment = self._generate_strategic_commentary(analysis['strategic_elements'])
                if strat_comment:
                    commentary_parts.append(strat_comment)
            
            # Add tactical situation commentary if applicable
            if analysis.get('tactical_situations') and analysis['tactical_situations']:
                tact_comment = self._generate_tactical_commentary(analysis['tactical_situations'])
                if tact_comment:
                    commentary_parts.append(tact_comment)
            
            # Combine all parts into a coherent commentary
            basic_commentary = " ".join(commentary_parts)
            
            # Add professional touches based on the type of position
            if analysis.get('strategic_elements', {}).get('strategic_theme') == 'middle_game_combination':
                basic_commentary += f" The middle game complexities require deep reading and understanding of mutual damage principles."
            elif analysis.get('strategic_elements', {}).get('strategic_theme') == 'endgame_technique':
                basic_commentary += f" Precise endgame technique will be crucial from this point forward."
        
        # Enhance the commentary to professional-level quality
        game_context = {
            'move_number': move_number,
            'phase': analysis.get('strategic_elements', {}).get('strategic_theme', 'middle_game'),
            'player': 'Black' if move_number and move_number % 2 == 1 else 'White',
            'position_type': analysis.get('strategic_elements', {}).get('strategic_theme', 'mixed'),
            'complexity': analysis.get('position_evaluation', {}).get('complexity', 0.5)
        }
        
        enhanced_commentary = self.professional_enhancer.enhance_commentary(basic_commentary, game_context)
        
        return enhanced_commentary.strip()
    
    def _generate_opening_commentary(self, analysis: Dict[str, Any]) -> str:
        """
        Generate commentary specific to opening moves
        """
        if analysis.get('strategic_elements', {}).get('strategic_theme') != 'fuseki':
            return ""
        
        frameworks = analysis.get('strategic_elements', {}).get('frameworks', {})
        if not frameworks:
            return ""
        
        # Check if the position is more territory-oriented or influence-oriented
        black_territory = frameworks.get('black', {}).get('territory_oriented', 0)
        black_influence = frameworks.get('black', {}).get('influence_oriented', 0)
        white_territory = frameworks.get('white', {}).get('territory_oriented', 0)
        white_influence = frameworks.get('white', {}).get('influence_oriented', 0)
        
        if black_influence > black_territory and white_influence > white_territory:
            return "Both players are building influence rather than taking territory, leading to a complex middle game."
        elif black_territory > black_influence or white_territory > white_influence:
            return "The players are focusing on securing territory in the corners and sides, creating a more positional game."
        else:
            return "A balanced fuseki with both territorial and influential ideas being pursued."
    
    def _generate_move_commentary(self, move_analysis: Dict[str, Any], move_number: int = None) -> str:
        """
        Generate commentary about a specific move
        """
        commentary = ""
        
        # Start with the move's purpose
        purpose = move_analysis.get('move_purpose', 'address the position')
        template = random.choice(self.commentary_templates['move_purpose'])
        commentary = template.format(
            purpose=purpose,
            side=random.choice(['left', 'right', 'top', 'bottom', 'center'])
        )
        
        # Add tactical considerations if applicable
        if move_analysis.get('tactical_response') or move_analysis.get('tactical_creation'):
            tactical_part = self._generate_tactical_part(move_analysis)
            if tactical_part:
                commentary += " " + tactical_part
        
        # Add pattern recognition if applicable
        if move_analysis.get('pattern_match') and move_analysis['pattern_match'].get('matches'):
            pattern_part = self._generate_pattern_part(move_analysis)
            if pattern_part:
                commentary += " " + pattern_part
        
        # Add evaluation impact if significant
        eval_impact = move_analysis.get('eval_impact', 0)
        if abs(eval_impact) > 3:  # Significant change in evaluation
            sign = "Black" if eval_impact > 0 else "White"
            magnitude = "slightly" if abs(eval_impact) < 6 else "significantly"
            commentary += f" This move {magnitude} improves {sign}'s position."
        
        return commentary
    
    def _generate_tactical_part(self, move_analysis: Dict[str, Any]) -> str:
        """
        Generate commentary about tactical aspects of the move
        """
        if move_analysis.get('tactical_response'):
            # Move was a response to a threat
            return random.choice([
                "This move correctly deals with the immediate tactical threat.",
                "A precise response to the tactical situation that arose.",
                "The move handles the tactical problem efficiently."
            ])
        elif move_analysis.get('tactical_creation'):
            # Move created a tactical opportunity
            return random.choice([
                "This move creates tactical complications that favor Black/White.",
                "A move that introduces tactical elements into the position.",
                "The position becomes sharper after this tactical insertion."
            ])
        else:
            return ""
    
    def _generate_pattern_part(self, move_analysis: Dict[str, Any]) -> str:
        """
        Generate commentary about pattern recognition
        """
        matches = move_analysis.get('pattern_match', {}).get('matches', [])
        if not matches:
            return ""
        
        # Take the highest confidence match
        best_match = max(matches, key=lambda x: x.get('confidence', 0))
        
        if best_match['confidence'] > 0.7:
            return f"This follows the classical {best_match['name']} pattern, demonstrating good joseki knowledge."
        elif best_match['confidence'] > 0.5:
            return f"The move resembles the {best_match['name']} pattern, though played in a slightly different context."
        else:
            return "An unconventional move that departs from standard patterns, showing creative thinking."
    
    def _generate_position_commentary(self, position_eval: Dict[str, Any]) -> str:
        """
        Generate commentary about the overall position evaluation
        """
        # Determine the evaluation summary
        black_advantage = position_eval.get('black_advantage', 0)
        win_prob = position_eval.get('win_probability', 0.5)
        complexity = position_eval.get('complexity', 0.5)
        
        if abs(black_advantage) < 3:
            eval_text = "The position is very close with both sides having equal chances"
        elif black_advantage > 0:
            if black_advantage > 10:
                eval_text = "Black has a clear advantage in this position"
            else:
                eval_text = "Black holds a slight advantage"
        else:
            if black_advantage < -10:
                eval_text = "White has a clear advantage in this position"
            else:
                eval_text = "White holds a slight advantage"
        
        # Determine complexity descriptor
        if complexity > 0.7:
            complexity_desc = "complicated"
        elif complexity > 0.4:
            complexity_desc = "moderately complex"
        else:
            complexity_desc = "relatively simple"
        
        # Combine evaluation with complexity
        template = random.choice(self.commentary_templates['evaluation'])
        commentary = template.format(
            evaluation=eval_text,
            adjective=complexity_desc,
            player="Black" if black_advantage > 0 else "White"
        )
        
        return commentary
    
    def _generate_strategic_commentary(self, strategic_elements: Dict[str, Any]) -> str:
        """
        Generate commentary about strategic elements
        """
        # Check for moyos
        moyos = strategic_elements.get('moyos', [])
        if moyos:
            largest_moyo = max(moyos, key=lambda x: x.get('size', 0))
            if largest_moyo['size'] > 20:
                return f"{largest_moyo['dominant_color'].title()} has established a large moyo on the {self._describe_side(largest_moyo['center_of_mass'])}, which will be a major factor in the middle game."
        
        # Check for strategic theme
        theme = strategic_elements.get('strategic_theme', '')
        if theme == 'middle_game_combination':
            return "The position has entered a complex middle game phase where tactical and strategic elements are intertwined."
        elif theme == 'endgame_technique':
            return "We've reached the endgame where precise technique will determine the outcome."
        else:
            return "The position maintains strategic balance with both players having viable plans."
    
    def _generate_tactical_commentary(self, tactical_situations: List[Dict[str, Any]]) -> str:
        """
        Generate commentary about tactical situations
        """
        if not tactical_situations:
            return ""
        
        # Count different types of tactical situations
        atari_count = sum(1 for t in tactical_situations if t.get('type') == 'atari')
        capture_count = sum(1 for t in tactical_situations if t.get('type') == 'potential_capture')
        ladder_count = sum(1 for t in tactical_situations if t.get('type') == 'ladder')
        
        commentary_parts = []
        
        if atari_count > 0:
            commentary_parts.append(f"There are {atari_count} group{'s' if atari_count > 1 else ''} currently in atari, requiring immediate attention.")
        
        if capture_count > 0:
            potential_captures = sum(t.get('captured_count', 0) for t in tactical_situations if t.get('type') == 'potential_capture')
            if potential_captures > 0:
                commentary_parts.append(f"There are potential captures involving {potential_captures} stone{'s' if potential_captures > 1 else ''}.")
        
        if ladder_count > 0:
            commentary_parts.append(f"At least one ladder is forming, which could become a major tactical sequence.")
        
        return " ".join(commentary_parts)
    
    def _describe_side(self, center: Tuple[float, float]) -> str:
        """
        Describe which side of the board a center point is on
        """
        x, y = center
        if x < 6 and y < 6:
            return "upper left corner"
        elif x > 12 and y < 6:
            return "upper right corner"
        elif x < 6 and y > 12:
            return "lower left corner"
        elif x > 12 and y > 12:
            return "lower right corner"
        elif x < 6:
            return "left side"
        elif x > 12:
            return "right side"
        elif y < 6:
            return "top side"
        elif y > 12:
            return "bottom side"
        else:
            return "center"
    
    def generate_detailed_commentary(self, analysis: Dict[str, Any], move_number: int = None) -> Dict[str, str]:
        """
        Generate detailed commentary broken down by aspect
        """
        return {
            'summary': self.generate_commentary(analysis, move_number),
            'position_evaluation': self._generate_position_commentary(analysis['position_evaluation']),
            'strategic_elements': self._generate_strategic_commentary(analysis['strategic_elements']) if analysis.get('strategic_elements') else "",
            'tactical_situations': self._generate_tactical_commentary(analysis['tactical_situations']) if analysis.get('tactical_situations') else "",
            'move_significance': self._generate_move_commentary(analysis['move_analysis'], move_number) if analysis.get('move_analysis') else ""
        }


def example_usage():
    """
    Example of how to use the commentary generator
    """
    generator = CommentaryGenerator()
    
    # Sample analysis data
    sample_analysis = {
        'position_evaluation': {
            'black_advantage': 5.2,
            'win_probability': 0.68,
            'complexity': 0.75,
            'balance': 0.3
        },
        'strategic_elements': {
            'moyos': [{
                'area': [(3, 3), (3, 4), (4, 3)],
                'dominant_color': 'black',
                'size': 25,
                'center_of_mass': (3.5, 3.5)
            }],
            'strategic_theme': 'middle_game_combination'
        },
        'tactical_situations': [
            {
                'type': 'atari',
                'group': [(10, 10), (10, 11)],
                'urgency': 'high'
            }
        ],
        'move_analysis': {
            'eval_impact': 2.1,
            'move_purpose': 'strengthen the position on the upper side',
            'tactical_response': True,
            'strategic_alignment': 'moyo building',
            'pattern_match': {
                'matches': [
                    {
                        'name': 'sanrensei',
                        'confidence': 0.8,
                        'description': 'Three-star formation',
                        'professional_frequency': 0.6
                    }
                ]
            }
        }
    }
    
    commentary = generator.generate_commentary(sample_analysis, move_number=45)
    print("Generated Commentary:")
    print(commentary)
    
    detailed = generator.generate_detailed_commentary(sample_analysis, move_number=45)
    print("\nDetailed Breakdown:")
    for key, value in detailed.items():
        print(f"{key.replace('_', ' ').title()}: {value}")
    
    return commentary


if __name__ == "__main__":
    example_usage()